// ============ DASHBOARD UI ============
function renderDashboard() {
    const { total_principal_outstanding = 0, active_loans_count = 0, total_interest_due = 0, overdue_loans_count = 0 } = AppState.stats;
    const overdueLoans = AppState.loans.filter(loan => isOverdue(loan));
    
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-7xl">
            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-4xl font-bold text-gray-800 mb-2">
                    <i class="fas fa-chart-line text-amber-500 mr-3"></i>Dashboard
                </h1>
                <p class="text-gray-600">Welcome back, ${AppState.user?.shop_name || 'User'}</p>
            </div>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-blue-500">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-coins text-blue-600 text-xl"></i>
                        </div>
                        <span class="text-sm font-semibold text-blue-600">PRINCIPAL</span>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800 mb-1">${formatCurrency(total_principal_outstanding)}</h3>
                    <p class="text-sm text-gray-600">${active_loans_count} Active Loans</p>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-green-500">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-percent text-green-600 text-xl"></i>
                        </div>
                        <span class="text-sm font-semibold text-green-600">INTEREST</span>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800 mb-1">${formatCurrency(total_interest_due)}</h3>
                    <p class="text-sm text-gray-600">Total Interest Due</p>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-amber-500">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-file-invoice-dollar text-amber-600 text-xl"></i>
                        </div>
                        <span class="text-sm font-semibold text-amber-600">ACTIVE</span>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800 mb-1">${active_loans_count}</h3>
                    <p class="text-sm text-gray-600">Active Loans</p>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-red-500 ${overdue_loans_count > 0 ? 'pulse-red' : ''}">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                        </div>
                        <span class="text-sm font-semibold text-red-600">OVERDUE</span>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800 mb-1">${overdue_loans_count}</h3>
                    <p class="text-sm text-gray-600">Loans >90 Days</p>
                </div>
            </div>
            
            <!-- Overdue Alerts -->
            ${overdue_loans_count > 0 ? `
                <div class="bg-red-50 border-l-4 border-red-500 rounded-lg p-6 mb-8">
                    <h3 class="text-xl font-bold text-red-800 mb-4">
                        <i class="fas fa-bell text-red-600 mr-2"></i>Overdue Alerts
                    </h3>
                    <div class="space-y-3">
                        ${overdueLoans.slice(0, 5).map(loan => `
                            <div class="bg-white rounded-lg p-4 flex items-center justify-between">
                                <div>
                                    <p class="font-semibold text-gray-800">${loan.customer_name}</p>
                                    <p class="text-sm text-gray-600">Loan #${loan.loan_number} • ${calculateDaysElapsed(loan.loan_date)} days</p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-red-600">${formatCurrency(loan.total_amount_due)}</p>
                                    <button onclick="openWhatsApp('${loan.customer_phone}', '${loan.customer_name}', '${loan.loan_number}', ${loan.interest_due})"
                                        class="text-sm text-green-600 hover:text-green-700 font-semibold mt-1">
                                        <i class="fab fa-whatsapp mr-1"></i>Send Reminder
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    ${overdueLoans.length > 5 ? `<p class="text-sm text-red-600 mt-4">+${overdueLoans.length - 5} more overdue loans</p>` : ''}
                </div>
            ` : ''}
            
            <!-- Recent Loans -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-history text-amber-500 mr-2"></i>Recent Loans
                    </h3>
                    <button onclick="showView('loans')" 
                        class="text-amber-600 hover:text-amber-700 font-semibold">
                        View All <i class="fas fa-arrow-right ml-1"></i>
                    </button>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="border-b-2 border-gray-200">
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Loan #</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Customer</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Principal</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Interest Due</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-700">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${AppState.loans.slice(0, 10).map(loan => `
                                <tr class="border-b border-gray-100 hover:bg-gray-50">
                                    <td class="py-4 px-4 font-medium text-gray-900">${loan.loan_number}</td>
                                    <td class="py-4 px-4">
                                        <div class="font-medium text-gray-900">${loan.customer_name}</div>
                                        <div class="text-sm text-gray-600">${loan.customer_phone}</div>
                                    </td>
                                    <td class="py-4 px-4 text-gray-700">${formatDate(loan.loan_date)}</td>
                                    <td class="py-4 px-4 font-semibold text-gray-900">${formatCurrency(loan.principal_remaining)}</td>
                                    <td class="py-4 px-4 font-semibold text-green-600">${formatCurrency(loan.interest_due)}</td>
                                    <td class="py-4 px-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                                            ${loan.status === 'active' ? 'bg-green-100 text-green-700' : 
                                              loan.status === 'closed' ? 'bg-gray-100 text-gray-700' : 
                                              'bg-red-100 text-red-700'}">
                                            ${loan.status.toUpperCase()}
                                        </span>
                                        ${isOverdue(loan) ? '<span class="ml-2 text-red-600"><i class="fas fa-exclamation-circle"></i></span>' : ''}
                                    </td>
                                    <td class="py-4 px-4">
                                        <button onclick="loadLoanDetails(${loan.id})" 
                                            class="text-amber-600 hover:text-amber-700 mr-2" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button onclick="openWhatsApp('${loan.customer_phone}', '${loan.customer_name}', '${loan.loan_number}', ${loan.interest_due})"
                                            class="text-green-600 hover:text-green-700" title="WhatsApp">
                                            <i class="fab fa-whatsapp"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    ${AppState.loans.length === 0 ? '<p class="text-center text-gray-500 py-8">No loans found</p>' : ''}
                </div>
            </div>
        </div>
    `;
}

// ============ NAVBAR ============
function renderNavbar() {
    return `
        <nav class="bg-white shadow-lg border-b-2 border-amber-500 sticky top-0 z-40">
            <div class="container mx-auto px-4">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center space-x-8">
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-gem text-white"></i>
                            </div>
                            <span class="text-xl font-bold text-gray-800">Gold Loan SaaS</span>
                        </div>
                        
                        <div class="hidden md:flex space-x-4">
                            <button onclick="showView('dashboard')" 
                                class="px-4 py-2 rounded-lg font-medium transition-all ${AppState.currentView === 'dashboard' ? 'bg-amber-100 text-amber-700' : 'text-gray-600 hover:bg-gray-100'}">
                                <i class="fas fa-chart-line mr-2"></i>Dashboard
                            </button>
                            <button onclick="showView('loans')" 
                                class="px-4 py-2 rounded-lg font-medium transition-all ${AppState.currentView === 'loans' ? 'bg-amber-100 text-amber-700' : 'text-gray-600 hover:bg-gray-100'}">
                                <i class="fas fa-file-invoice-dollar mr-2"></i>Loans
                            </button>
                            <button onclick="showView('customers')" 
                                class="px-4 py-2 rounded-lg font-medium transition-all ${AppState.currentView === 'customers' ? 'bg-amber-100 text-amber-700' : 'text-gray-600 hover:bg-gray-100'}">
                                <i class="fas fa-users mr-2"></i>Customers
                            </button>
                            <button onclick="showView('settings')" 
                                class="px-4 py-2 rounded-lg font-medium transition-all ${AppState.currentView === 'settings' ? 'bg-amber-100 text-amber-700' : 'text-gray-600 hover:bg-gray-100'}">
                                <i class="fas fa-cog mr-2"></i>Settings
                            </button>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <button onclick="showView('newLoan')" 
                            class="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-2 rounded-lg font-semibold hover:shadow-lg transition-all">
                            <i class="fas fa-plus mr-2"></i>New Loan
                        </button>
                        <button onclick="logout()" 
                            class="text-gray-600 hover:text-red-600 px-4 py-2 rounded-lg font-medium transition-all">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </button>
                    </div>
                </div>
            </div>
        </nav>
    `;
}

// WhatsApp Integration
window.openWhatsApp = (phone, name, loanNumber, interestDue) => {
    const message = `Dear ${name},%0A%0AYour interest payment of ${formatCurrency(interestDue)} is due for Loan ID: ${loanNumber}.%0A%0APlease make the payment at your earliest convenience.%0A%0AThank you,%0A${AppState.user?.shop_name || 'Gold Loan SaaS'}`;
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
};

// ============ NEW LOAN UI ============
let newLoanImages = {
    customer: null,
    product: null
};

function renderNewLoan() {
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <div class="mb-6">
                <button onclick="showView('loans')" class="text-amber-600 hover:text-amber-700 font-semibold mb-4">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Loans
                </button>
                <h1 class="text-4xl font-bold text-gray-800">
                    <i class="fas fa-plus-circle text-amber-500 mr-3"></i>Create New Loan
                </h1>
            </div>
            
            <form onsubmit="handleNewLoan(event)" class="bg-white rounded-xl shadow-lg p-8 space-y-6">
                <!-- Customer Information -->
                <div class="border-b pb-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">
                        <i class="fas fa-user text-amber-500 mr-2"></i>Customer Information
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Customer Name *</label>
                            <input type="text" id="customerName" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                            <input type="tel" id="customerPhone" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                placeholder="+91 98765 43210">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                            <textarea id="customerAddress" rows="2"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">ID Proof Type</label>
                            <select id="idProofType" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                <option value="">Select ID Type</option>
                                <option value="Aadhaar">Aadhaar Card</option>
                                <option value="PAN">PAN Card</option>
                                <option value="Voter">Voter ID</option>
                                <option value="Passport">Passport</option>
                                <option value="Driving">Driving License</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">ID Proof Number</label>
                            <input type="text" id="idProofNumber"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Customer Photo</label>
                            <div class="flex items-center space-x-4">
                                <button type="button" onclick="captureImage('customer')"
                                    class="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all">
                                    <i class="fas fa-camera mr-2"></i>Capture Photo
                                </button>
                                <input type="file" id="customerPhotoFile" accept="image/*" capture="user" class="hidden" onchange="handleImageSelect('customer')">
                                <div id="customerPhotoPreview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Product/Gold Details -->
                <div class="border-b pb-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">
                        <i class="fas fa-gem text-amber-500 mr-2"></i>Gold Ornament Details
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Gross Weight (grams) *</label>
                            <input type="number" id="grossWeight" required step="0.001" min="0" onchange="calculateWeightAndAmount()"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Stone Weight (grams)</label>
                            <input type="number" id="stoneWeight" value="0" step="0.001" min="0" onchange="calculateWeightAndAmount()"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Net Weight (grams) *</label>
                            <input type="number" id="netWeight" readonly
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100 font-bold">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Purity *</label>
                            <select id="purity" required onchange="calculateWeightAndAmount()"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                <option value="">Select Purity</option>
                                <option value="18K">18K (75%)</option>
                                <option value="22K">22K (91.67%)</option>
                                <option value="24K">24K (100%)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Gold Rate (₹/gram) *</label>
                            <input type="number" id="goldRate" required step="0.01" min="0" onchange="calculateWeightAndAmount()"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                placeholder="7000">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">LTV % *</label>
                            <input type="number" id="ltvPercent" value="75" required step="0.1" min="0" max="100" onchange="calculateWeightAndAmount()"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Loan Amount (₹)</label>
                            <input type="number" id="loanAmount" readonly
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-amber-50 font-bold text-2xl text-amber-700">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Product Photo *</label>
                            <div class="flex items-center space-x-4">
                                <button type="button" onclick="captureImage('product')"
                                    class="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all">
                                    <i class="fas fa-camera mr-2"></i>Capture Photo
                                </button>
                                <input type="file" id="productPhotoFile" accept="image/*" capture="environment" class="hidden" onchange="handleImageSelect('product')">
                                <div id="productPhotoPreview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Interest Rates -->
                <div class="border-b pb-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">
                        <i class="fas fa-percent text-amber-500 mr-2"></i>Interest Rate Configuration
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">0-30 Days Rate (%)</label>
                            <input type="number" id="rate30" value="1.5" step="0.1" min="0"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">31-60 Days Rate (%)</label>
                            <input type="number" id="rate60" value="2.0" step="0.1" min="0"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">61+ Days Rate (%)</label>
                            <input type="number" id="rate90" value="2.5" step="0.1" min="0"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                        </div>
                    </div>
                </div>
                
                <!-- Loan Date -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Loan Date *</label>
                    <input type="date" id="loanDate" required value="${new Date().toISOString().split('T')[0]}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                </div>
                
                <!-- Submit -->
                <div class="flex space-x-4">
                    <button type="submit" 
                        class="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold py-4 rounded-lg hover:shadow-lg transition-all text-lg">
                        <i class="fas fa-check-circle mr-2"></i>Create Loan & Generate PDF
                    </button>
                    <button type="button" onclick="showView('loans')"
                        class="px-8 py-4 border-2 border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition-all">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    `;
}

window.calculateWeightAndAmount = () => {
    const gross = parseFloat(document.getElementById('grossWeight')?.value || 0);
    const stone = parseFloat(document.getElementById('stoneWeight')?.value || 0);
    const purity = document.getElementById('purity')?.value;
    const goldRate = parseFloat(document.getElementById('goldRate')?.value || 0);
    const ltv = parseFloat(document.getElementById('ltvPercent')?.value || 75);
    
    // Calculate net weight
    const netWeight = Math.round((gross - stone) * 1000) / 1000;
    if (document.getElementById('netWeight')) {
        document.getElementById('netWeight').value = netWeight;
    }
    
    // Calculate loan amount
    if (purity && goldRate && netWeight > 0) {
        const purityFactors = { '18K': 0.75, '22K': 0.9167, '24K': 1.0 };
        const purityFactor = purityFactors[purity] || 1;
        const goldValue = netWeight * goldRate * purityFactor;
        const loanAmount = Math.round((goldValue * ltv) / 100);
        
        if (document.getElementById('loanAmount')) {
            document.getElementById('loanAmount').value = loanAmount;
        }
    }
};

window.captureImage = (type) => {
    const fileInput = document.getElementById(`${type}PhotoFile`);
    fileInput.click();
};

window.handleImageSelect = async (type) => {
    const fileInput = document.getElementById(`${type}PhotoFile`);
    const file = fileInput.files[0];
    
    if (!file) return;
    
    try {
        // Show preview
        const preview = document.getElementById(`${type}PhotoPreview`);
        preview.innerHTML = '<span class="text-sm text-gray-600"><i class="fas fa-spinner fa-spin mr-2"></i>Compressing...</span>';
        
        // Compress image
        const compressed = await compressImage(file);
        newLoanImages[type] = compressed;
        
        // Show success
        preview.innerHTML = `<span class="text-sm text-green-600"><i class="fas fa-check-circle mr-2"></i>${(compressed.size / 1024).toFixed(0)}KB</span>`;
    } catch (error) {
        console.error('Image processing error:', error);
        showError('Failed to process image');
    }
};

window.handleNewLoan = async (e) => {
    e.preventDefault();
    
    try {
        // Upload images first
        let customerPhotoUrl = null;
        let productPhotoUrl = null;
        
        if (newLoanImages.customer) {
            customerPhotoUrl = await uploadFile(newLoanImages.customer, 'customer');
        }
        
        if (newLoanImages.product) {
            productPhotoUrl = await uploadFile(newLoanImages.product, 'product');
        } else {
            showError('Product photo is required');
            return;
        }
        
        // Create loan
        const loanData = {
            customer_name: document.getElementById('customerName').value,
            customer_phone: document.getElementById('customerPhone').value,
            customer_address: document.getElementById('customerAddress').value,
            id_proof_type: document.getElementById('idProofType').value,
            id_proof_number: document.getElementById('idProofNumber').value,
            customer_photo_url: customerPhotoUrl,
            product_photo_url: productPhotoUrl,
            gross_weight: parseFloat(document.getElementById('grossWeight').value),
            stone_weight: parseFloat(document.getElementById('stoneWeight').value),
            purity: document.getElementById('purity').value,
            gold_rate_per_gram: parseFloat(document.getElementById('goldRate').value),
            ltv_percentage: parseFloat(document.getElementById('ltvPercent').value),
            interest_rate_30: parseFloat(document.getElementById('rate30').value),
            interest_rate_60: parseFloat(document.getElementById('rate60').value),
            interest_rate_90: parseFloat(document.getElementById('rate90').value),
            loan_date: document.getElementById('loanDate').value
        };
        
        const res = await api.post('/loans', loanData);
        
        showSuccess('Loan created successfully!');
        
        // Generate PDF
        await generateLoanPDF(res.data.loan_id);
        
        // Reset form
        newLoanImages = { customer: null, product: null };
        
        // Navigate to loan details
        showView('loans');
    } catch (error) {
        console.error('Loan creation error:', error);
        showError(error.response?.data?.error || 'Failed to create loan');
    }
};

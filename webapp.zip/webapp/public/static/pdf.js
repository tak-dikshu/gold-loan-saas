// ============ PDF GENERATION ============
// Note: This uses jsPDF which is loaded via CDN

window.generateLoanPDF = async (loanId) => {
    try {
        // Load loan and settings
        const [loanRes, settingsRes] = await Promise.all([
            api.get(`/loans/${loanId}`),
            api.get('/settings')
        ]);
        
        const { loan } = loanRes.data;
        const settings = settingsRes.data;
        
        // Import jsPDF from window
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        let yPos = 20;
        
        // Add logo if available
        if (settings.shop_logo_url) {
            try {
                // Load logo as data URL
                const logoData = await fetch(settings.shop_logo_url).then(r => r.blob()).then(b => {
                    return new Promise((resolve) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.readAsDataURL(b);
                    });
                });
                doc.addImage(logoData, 'PNG', 15, yPos, 40, 40);
                yPos += 45;
            } catch (e) {
                console.error('Logo load error:', e);
                yPos += 10;
            }
        }
        
        // Header
        doc.setFontSize(22);
        doc.setFont(undefined, 'bold');
        doc.text(AppState.user?.shop_name || 'Gold Loan SaaS', 105, yPos, { align: 'center' });
        yPos += 10;
        
        doc.setFontSize(16);
        doc.text('GOLD LOAN SANCTION LETTER', 105, yPos, { align: 'center' });
        yPos += 15;
        
        // Loan Details
        doc.setFontSize(12);
        doc.setFont(undefined, 'normal');
        
        doc.setFont(undefined, 'bold');
        doc.text('Loan Number:', 15, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(loan.loan_number, 60, yPos);
        yPos += 8;
        
        doc.setFont(undefined, 'bold');
        doc.text('Loan Date:', 15, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(formatDate(loan.loan_date), 60, yPos);
        yPos += 8;
        
        doc.setFont(undefined, 'bold');
        doc.text('Status:', 15, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(loan.status.toUpperCase(), 60, yPos);
        yPos += 12;
        
        // Customer Information
        doc.setFillColor(245, 158, 11);
        doc.rect(15, yPos, 180, 8, 'F');
        doc.setFont(undefined, 'bold');
        doc.setTextColor(255, 255, 255);
        doc.text('CUSTOMER INFORMATION', 20, yPos + 6);
        doc.setTextColor(0, 0, 0);
        yPos += 12;
        
        doc.setFont(undefined, 'bold');
        doc.text('Name:', 15, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(loan.customer_name, 60, yPos);
        yPos += 8;
        
        doc.setFont(undefined, 'bold');
        doc.text('Phone:', 15, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(loan.customer_phone, 60, yPos);
        yPos += 8;
        
        if (loan.customer_address) {
            doc.setFont(undefined, 'bold');
            doc.text('Address:', 15, yPos);
            doc.setFont(undefined, 'normal');
            const addressLines = doc.splitTextToSize(loan.customer_address, 130);
            doc.text(addressLines, 60, yPos);
            yPos += addressLines.length * 6 + 4;
        }
        yPos += 4;
        
        // Gold Details
        doc.setFillColor(245, 158, 11);
        doc.rect(15, yPos, 180, 8, 'F');
        doc.setFont(undefined, 'bold');
        doc.setTextColor(255, 255, 255);
        doc.text('GOLD ORNAMENT DETAILS', 20, yPos + 6);
        doc.setTextColor(0, 0, 0);
        yPos += 12;
        
        const goldDetails = [
            ['Gross Weight:', `${loan.gross_weight}g`],
            ['Stone Weight:', `${loan.stone_weight}g`],
            ['Net Weight:', `${loan.net_weight}g`],
            ['Purity:', loan.purity],
            ['Gold Rate:', `${formatCurrency(loan.gold_rate_per_gram)}/gram`],
            ['LTV Percentage:', `${loan.ltv_percentage}%`]
        ];
        
        goldDetails.forEach(([label, value]) => {
            doc.setFont(undefined, 'bold');
            doc.text(label, 15, yPos);
            doc.setFont(undefined, 'normal');
            doc.text(value, 60, yPos);
            yPos += 8;
        });
        yPos += 4;
        
        // Financial Details
        doc.setFillColor(245, 158, 11);
        doc.rect(15, yPos, 180, 8, 'F');
        doc.setFont(undefined, 'bold');
        doc.setTextColor(255, 255, 255);
        doc.text('FINANCIAL DETAILS', 20, yPos + 6);
        doc.setTextColor(0, 0, 0);
        yPos += 12;
        
        doc.setFontSize(14);
        doc.setFont(undefined, 'bold');
        doc.text('Loan Amount:', 15, yPos);
        doc.text(formatCurrency(loan.loan_amount), 150, yPos);
        yPos += 10;
        
        doc.setFontSize(12);
        doc.setFont(undefined, 'normal');
        doc.text('Principal Remaining:', 15, yPos);
        doc.text(formatCurrency(loan.principal_remaining), 150, yPos);
        yPos += 8;
        
        const interest = calculateInterest(loan);
        doc.text('Interest Due:', 15, yPos);
        doc.text(formatCurrency(interest), 150, yPos);
        yPos += 8;
        
        doc.setFont(undefined, 'bold');
        doc.text('Total Amount Due:', 15, yPos);
        doc.text(formatCurrency(loan.principal_remaining + interest), 150, yPos);
        yPos += 12;
        
        // Interest Rates
        doc.setFont(undefined, 'bold');
        doc.text('Interest Rate Structure:', 15, yPos);
        yPos += 8;
        doc.setFont(undefined, 'normal');
        doc.text(`0-30 Days: ${loan.interest_rate_30}% per month`, 20, yPos);
        yPos += 6;
        doc.text(`31-60 Days: ${loan.interest_rate_60}% per month`, 20, yPos);
        yPos += 6;
        doc.text(`61+ Days: ${loan.interest_rate_90}% per month`, 20, yPos);
        yPos += 12;
        
        // Payment Details - Only if settings available
        if (settings.bank_name || settings.upi_id) {
            // Check if we need a new page
            if (yPos > 240) {
                doc.addPage();
                yPos = 20;
            }
            
            doc.setFillColor(245, 158, 11);
            doc.rect(15, yPos, 180, 8, 'F');
            doc.setFont(undefined, 'bold');
            doc.setTextColor(255, 255, 255);
            doc.text('PAYMENT DETAILS', 20, yPos + 6);
            doc.setTextColor(0, 0, 0);
            yPos += 12;
            
            if (settings.bank_name) {
                doc.setFont(undefined, 'bold');
                doc.text('Bank Details:', 15, yPos);
                yPos += 8;
                doc.setFont(undefined, 'normal');
                doc.text(`Bank: ${settings.bank_name}`, 20, yPos);
                yPos += 6;
                if (settings.account_number) {
                    doc.text(`Account: ${settings.account_number}`, 20, yPos);
                    yPos += 6;
                }
                if (settings.ifsc_code) {
                    doc.text(`IFSC: ${settings.ifsc_code}`, 20, yPos);
                    yPos += 6;
                }
                if (settings.branch) {
                    doc.text(`Branch: ${settings.branch}`, 20, yPos);
                    yPos += 6;
                }
                yPos += 4;
            }
            
            if (settings.upi_id) {
                doc.setFont(undefined, 'bold');
                doc.text('UPI ID:', 15, yPos);
                doc.setFont(undefined, 'normal');
                doc.text(settings.upi_id, 60, yPos);
                yPos += 10;
            }
            
            // Add QR Code if available
            if (settings.payment_qr_code_url) {
                try {
                    const qrData = await fetch(settings.payment_qr_code_url).then(r => r.blob()).then(b => {
                        return new Promise((resolve) => {
                            const reader = new FileReader();
                            reader.onloadend = () => resolve(reader.result);
                            reader.readAsDataURL(b);
                        });
                    });
                    doc.addImage(qrData, 'PNG', 15, yPos, 50, 50);
                    doc.setFontSize(10);
                    doc.text('Scan to pay', 70, yPos + 25);
                    yPos += 55;
                } catch (e) {
                    console.error('QR load error:', e);
                }
            }
        }
        
        // Footer
        doc.setFontSize(10);
        doc.setFont(undefined, 'italic');
        doc.setTextColor(100, 100, 100);
        doc.text('This is a computer-generated document and does not require a signature.', 105, 280, { align: 'center' });
        doc.text(`Generated on ${formatDate(new Date().toISOString())} via Gold Loan SaaS`, 105, 285, { align: 'center' });
        
        // Save PDF
        doc.save(`Loan_${loan.loan_number}.pdf`);
        
        showSuccess('PDF generated successfully!');
    } catch (error) {
        console.error('PDF generation error:', error);
        showError('Failed to generate PDF');
    }
};

window.downloadLoanPDF = async (loanId) => {
    await generateLoanPDF(loanId);
};

window.printLoan = async (loanId) => {
    // Generate PDF and open in new window for printing
    const loanRes = await api.get(`/loans/${loanId}`);
    const settingsRes = await api.get('/settings');
    
    const { loan } = loanRes.data;
    const settings = settingsRes.data;
    
    // Open print window with formatted content
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Loan ${loan.loan_number}</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 40px; }
                h1 { color: #F59E0B; border-bottom: 3px solid #F59E0B; padding-bottom: 10px; }
                .section { margin: 20px 0; }
                .label { font-weight: bold; display: inline-block; width: 150px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
                th { background-color: #F59E0B; color: white; }
            </style>
        </head>
        <body>
            ${settings.shop_logo_url ? `<img src="${settings.shop_logo_url}" style="height: 60px; margin-bottom: 20px;">` : ''}
            <h1>${AppState.user?.shop_name || 'Gold Loan SaaS'}</h1>
            <h2>Loan Sanction Letter</h2>
            <div class="section">
                <p><span class="label">Loan Number:</span> ${loan.loan_number}</p>
                <p><span class="label">Date:</span> ${formatDate(loan.loan_date)}</p>
                <p><span class="label">Status:</span> ${loan.status.toUpperCase()}</p>
            </div>
            <h3>Customer Details</h3>
            <div class="section">
                <p><span class="label">Name:</span> ${loan.customer_name}</p>
                <p><span class="label">Phone:</span> ${loan.customer_phone}</p>
                ${loan.customer_address ? `<p><span class="label">Address:</span> ${loan.customer_address}</p>` : ''}
            </div>
            <h3>Gold Details</h3>
            <table>
                <tr><td class="label">Gross Weight</td><td>${loan.gross_weight}g</td></tr>
                <tr><td class="label">Stone Weight</td><td>${loan.stone_weight}g</td></tr>
                <tr><td class="label">Net Weight</td><td>${loan.net_weight}g</td></tr>
                <tr><td class="label">Purity</td><td>${loan.purity}</td></tr>
                <tr><td class="label">Gold Rate</td><td>${formatCurrency(loan.gold_rate_per_gram)}/gram</td></tr>
            </table>
            <h3>Financial Details</h3>
            <table>
                <tr><td class="label">Loan Amount</td><td><strong>${formatCurrency(loan.loan_amount)}</strong></td></tr>
                <tr><td class="label">Principal Remaining</td><td>${formatCurrency(loan.principal_remaining)}</td></tr>
                <tr><td class="label">Interest Due</td><td>${formatCurrency(calculateInterest(loan))}</td></tr>
                <tr><td class="label">Total Amount Due</td><td><strong>${formatCurrency(loan.principal_remaining + calculateInterest(loan))}</strong></td></tr>
            </table>
            ${settings.bank_name ? `
                <h3>Payment Details</h3>
                <div class="section">
                    <p><span class="label">Bank:</span> ${settings.bank_name}</p>
                    ${settings.account_number ? `<p><span class="label">Account:</span> ${settings.account_number}</p>` : ''}
                    ${settings.ifsc_code ? `<p><span class="label">IFSC:</span> ${settings.ifsc_code}</p>` : ''}
                    ${settings.upi_id ? `<p><span class="label">UPI ID:</span> ${settings.upi_id}</p>` : ''}
                    ${settings.payment_qr_code_url ? `<img src="${settings.payment_qr_code_url}" style="width: 150px; margin-top: 10px;">` : ''}
                </div>
            ` : ''}
            <script>window.print(); window.close();</script>
        </body>
        </html>
    `);
};

// Gold Loan Management SaaS - Frontend Application
// Complete Production-Ready System

const API_BASE = '/api';

// ============ STATE MANAGEMENT ============
const AppState = {
    token: localStorage.getItem('goldLoanToken'),
    user: JSON.parse(localStorage.getItem('goldLoanUser') || 'null'),
    currentView: 'dashboard',
    loans: [],
    customers: [],
    transactions: [],
    settings: null,
    stats: {},
    selectedLoan: null,
    filters: {
        status: 'all',
        search: '',
        startDate: '',
        endDate: ''
    }
};

// ============ API CLIENT ============
const api = axios.create({
    baseURL: API_BASE,
    headers: {
        'Content-Type': 'application/json'
    }
});

api.interceptors.request.use(config => {
    if (AppState.token) {
        config.headers.Authorization = `Bearer ${AppState.token}`;
    }
    return config;
});

api.interceptors.response.use(
    response => response,
    error => {
        if (error.response?.status === 401) {
            logout();
        }
        return Promise.reject(error);
    }
);

// ============ UTILITY FUNCTIONS ============
function formatCurrency(amount) {
    return `₹${Number(amount).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
}

function calculateDaysElapsed(loanDate) {
    const start = new Date(loanDate);
    const today = new Date();
    const diffTime = Math.abs(today - start);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function calculateInterest(loan) {
    const days = calculateDaysElapsed(loan.loan_date);
    let rate = loan.interest_rate_30;
    
    if (days > 60) rate = loan.interest_rate_90;
    else if (days > 30) rate = loan.interest_rate_60;
    
    const interest = (loan.principal_remaining * rate * days) / 100 / 30;
    return Math.round(interest * 100) / 100;
}

function isOverdue(loan) {
    return calculateDaysElapsed(loan.loan_date) > 90 && loan.status === 'active';
}

async function compressImage(file, maxSizeMB = 0.4) {
    const options = {
        maxSizeMB,
        maxWidthOrHeight: 1920,
        useWebWorker: true
    };
    return await imageCompression(file, options);
}

// ============ AUTH FUNCTIONS ============
function setAuth(token, user) {
    AppState.token = token;
    AppState.user = user;
    localStorage.setItem('goldLoanToken', token);
    localStorage.setItem('goldLoanUser', JSON.stringify(user));
}

function logout() {
    AppState.token = null;
    AppState.user = null;
    localStorage.removeItem('goldLoanToken');
    localStorage.removeItem('goldLoanUser');
    showView('auth');
}

// ============ DATA LOADING FUNCTIONS ============
async function loadDashboardData() {
    try {
        const [loansRes, statsRes, settingsRes] = await Promise.all([
            api.get('/loans'),
            api.get('/loans/stats/dashboard'),
            api.get('/settings')
        ]);
        
        AppState.loans = loansRes.data.loans || [];
        AppState.stats = statsRes.data || {};
        AppState.settings = settingsRes.data || {};
        
        renderDashboard();
    } catch (error) {
        console.error('Dashboard load error:', error);
        showError('Failed to load dashboard data');
    }
}

async function loadLoans(filters = {}) {
    try {
        const params = new URLSearchParams();
        if (filters.status && filters.status !== 'all') params.append('status', filters.status);
        if (filters.search) params.append('search', filters.search);
        if (filters.startDate) params.append('start_date', filters.startDate);
        if (filters.endDate) params.append('end_date', filters.endDate);
        
        const res = await api.get(`/loans?${params}`);
        AppState.loans = res.data.loans || [];
        renderLoans();
    } catch (error) {
        console.error('Loans load error:', error);
        showError('Failed to load loans');
    }
}

async function loadLoanDetails(loanId) {
    try {
        const res = await api.get(`/loans/${loanId}`);
        AppState.selectedLoan = res.data;
        renderLoanDetails();
    } catch (error) {
        console.error('Loan details error:', error);
        showError('Failed to load loan details');
    }
}

async function loadCustomers() {
    try {
        const res = await api.get('/customers');
        AppState.customers = res.data.customers || [];
        renderCustomers();
    } catch (error) {
        console.error('Customers load error:', error);
        showError('Failed to load customers');
    }
}

async function loadSettings() {
    try {
        const res = await api.get('/settings');
        AppState.settings = res.data;
        renderSettings();
    } catch (error) {
        console.error('Settings load error:', error);
        showError('Failed to load settings');
    }
}

// ============ FILE UPLOAD ============
async function uploadFile(file, type) {
    try {
        const compressed = await compressImage(file);
        const formData = new FormData();
        formData.append('file', compressed);
        formData.append('type', type);
        
        const res = await api.post('/settings/upload', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });
        
        return res.data.url;
    } catch (error) {
        console.error('Upload error:', error);
        throw error;
    }
}

// ============ NAVIGATION ============
function showView(view) {
    AppState.currentView = view;
    
    if (view === 'auth') {
        renderAuth();
    } else if (!AppState.token) {
        renderAuth();
        return;
    } else if (view === 'dashboard') {
        loadDashboardData();
    } else if (view === 'loans') {
        loadLoans(AppState.filters);
    } else if (view === 'newLoan') {
        renderNewLoan();
    } else if (view === 'customers') {
        loadCustomers();
    } else if (view === 'settings') {
        loadSettings();
    } else if (view === 'audit') {
        loadAuditLogs();
    }
}

function showError(message) {
    const app = document.getElementById('app');
    const errorDiv = document.createElement('div');
    errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 animate-bounce';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle mr-2"></i>${message}`;
    app.appendChild(errorDiv);
    
    setTimeout(() => errorDiv.remove(), 3000);
}

function showSuccess(message) {
    const app = document.getElementById('app');
    const successDiv = document.createElement('div');
    successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50';
    successDiv.innerHTML = `<i class="fas fa-check-circle mr-2"></i>${message}`;
    app.appendChild(successDiv);
    
    setTimeout(() => successDiv.remove(), 3000);
}

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    if (AppState.token) {
        showView('dashboard');
    } else {
        showView('auth');
    }
    
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/sw.js').catch(err => {
            console.log('Service worker registration failed:', err);
        });
    }
});

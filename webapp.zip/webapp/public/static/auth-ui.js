// ============ AUTH UI ============
function renderAuth() {
    document.getElementById('app').innerHTML = `
        <div class="min-h-screen flex items-center justify-center p-4">
            <div class="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
                <div class="text-center mb-8">
                    <div class="w-20 h-20 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <i class="fas fa-gem text-white text-3xl"></i>
                    </div>
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">Gold Loan SaaS</h1>
                    <p class="text-gray-600">Professional Loan Management for Jewelers</p>
                </div>
                
                <div id="authTabs" class="flex border-b mb-6">
                    <button onclick="switchAuthTab('login')" id="loginTab" 
                        class="flex-1 py-3 font-semibold border-b-2 border-amber-500 text-amber-600">
                        Login
                    </button>
                    <button onclick="switchAuthTab('register')" id="registerTab" 
                        class="flex-1 py-3 font-semibold text-gray-500 hover:text-gray-700">
                        Register
                    </button>
                </div>
                
                <div id="loginForm">
                    <form onsubmit="handleLogin(event)" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" id="loginEmail" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="your@email.com">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                            <input type="password" id="loginPassword" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="••••••••">
                        </div>
                        <button type="submit" 
                            class="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold py-3 rounded-lg hover:shadow-lg transition-all">
                            <i class="fas fa-sign-in-alt mr-2"></i>Login
                        </button>
                    </form>
                </div>
                
                <div id="registerForm" class="hidden">
                    <form onsubmit="handleRegister(event)" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Shop Name</label>
                            <input type="text" id="regShopName" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="Golden Jewelers">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" id="regEmail" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="shop@email.com">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                            <input type="tel" id="regPhone"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="+91 98765 43210">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                            <input type="password" id="regPassword" required minlength="6"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                                placeholder="••••••••">
                        </div>
                        <button type="submit" 
                            class="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold py-3 rounded-lg hover:shadow-lg transition-all">
                            <i class="fas fa-user-plus mr-2"></i>Register Shop
                        </button>
                    </form>
                </div>
            </div>
        </div>
    `;
}

window.switchAuthTab = (tab) => {
    const loginTab = document.getElementById('loginTab');
    const registerTab = document.getElementById('registerTab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (tab === 'login') {
        loginTab.className = 'flex-1 py-3 font-semibold border-b-2 border-amber-500 text-amber-600';
        registerTab.className = 'flex-1 py-3 font-semibold text-gray-500 hover:text-gray-700';
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
    } else {
        registerTab.className = 'flex-1 py-3 font-semibold border-b-2 border-amber-500 text-amber-600';
        loginTab.className = 'flex-1 py-3 font-semibold text-gray-500 hover:text-gray-700';
        registerForm.classList.remove('hidden');
        loginForm.classList.add('hidden');
    }
};

window.handleLogin = async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const res = await api.post('/auth/login', { email, password });
        setAuth(res.data.token, {
            tenant_id: res.data.tenant_id,
            shop_name: res.data.shop_name,
            email: res.data.email
        });
        showSuccess('Login successful!');
        showView('dashboard');
    } catch (error) {
        showError(error.response?.data?.error || 'Login failed');
    }
};

window.handleRegister = async (e) => {
    e.preventDefault();
    const shop_name = document.getElementById('regShopName').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const password = document.getElementById('regPassword').value;
    
    try {
        const res = await api.post('/auth/register', { shop_name, email, phone, password });
        setAuth(res.data.token, {
            tenant_id: res.data.tenant_id,
            shop_name: res.data.shop_name,
            email: res.data.email
        });
        showSuccess('Registration successful!');
        showView('dashboard');
    } catch (error) {
        showError(error.response?.data?.error || 'Registration failed');
    }
};

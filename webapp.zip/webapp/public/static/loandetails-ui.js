// ============ LOAN DETAILS UI ============
function renderLoanDetails() {
    const { loan, transactions } = AppState.selectedLoan || {};
    if (!loan) return;
    
    const interest = calculateInterest(loan);
    const totalDue = loan.principal_remaining + interest;
    
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-6xl">
            <div class="mb-6">
                <button onclick="showView('loans')" class="text-amber-600 hover:text-amber-700 font-semibold mb-4">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Loans
                </button>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Loan Info -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- Loan Header -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <div class="flex items-start justify-between mb-4">
                            <div>
                                <h1 class="text-3xl font-bold text-gray-800 mb-2">Loan #${loan.loan_number}</h1>
                                <p class="text-gray-600">Created on ${formatDate(loan.loan_date)}</p>
                            </div>
                            <div class="text-right">
                                <span class="px-4 py-2 rounded-full text-sm font-semibold
                                    ${loan.status === 'active' ? 'bg-green-100 text-green-700' : 
                                      loan.status === 'closed' ? 'bg-gray-100 text-gray-700' : 
                                      'bg-red-100 text-red-700'}">
                                    ${loan.status.toUpperCase()}
                                </span>
                                ${isOverdue(loan) ? '<div class="text-red-600 font-semibold mt-2 pulse-red">⚠️ OVERDUE</div>' : ''}
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-blue-50 rounded-lg p-4">
                                <p class="text-sm text-blue-600 font-semibold mb-1">PRINCIPAL REMAINING</p>
                                <p class="text-2xl font-bold text-blue-700">${formatCurrency(loan.principal_remaining)}</p>
                            </div>
                            <div class="bg-green-50 rounded-lg p-4">
                                <p class="text-sm text-green-600 font-semibold mb-1">INTEREST DUE</p>
                                <p class="text-2xl font-bold text-green-700">${formatCurrency(interest)}</p>
                            </div>
                            <div class="bg-amber-50 rounded-lg p-4">
                                <p class="text-sm text-amber-600 font-semibold mb-1">DAYS ELAPSED</p>
                                <p class="text-2xl font-bold text-amber-700">${calculateDaysElapsed(loan.loan_date)} days</p>
                            </div>
                            <div class="bg-purple-50 rounded-lg p-4">
                                <p class="text-sm text-purple-600 font-semibold mb-1">TOTAL DUE</p>
                                <p class="text-2xl font-bold text-purple-700">${formatCurrency(totalDue)}</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Customer Info -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-user text-amber-500 mr-2"></i>Customer Details
                        </h3>
                        <div class="flex items-start space-x-6">
                            ${loan.customer_photo_url ? `
                                <img src="${loan.customer_photo_url}" alt="${loan.customer_name}" 
                                    class="w-24 h-24 rounded-lg object-cover border-2 border-gray-200">
                            ` : ''}
                            <div class="flex-1">
                                <p class="text-lg font-bold text-gray-800">${loan.customer_name}</p>
                                <p class="text-gray-600"><i class="fas fa-phone mr-2"></i>${loan.customer_phone}</p>
                                ${loan.customer_address ? `<p class="text-gray-600 mt-2"><i class="fas fa-map-marker-alt mr-2"></i>${loan.customer_address}</p>` : ''}
                                <button onclick="openWhatsApp('${loan.customer_phone}', '${loan.customer_name}', '${loan.loan_number}', ${interest})"
                                    class="mt-4 px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all">
                                    <i class="fab fa-whatsapp mr-2"></i>Send Payment Reminder
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product Details -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-gem text-amber-500 mr-2"></i>Gold Ornament Details
                        </h3>
                        ${loan.product_photo_url ? `
                            <img src="${loan.product_photo_url}" alt="Product" 
                                class="w-full max-w-sm rounded-lg mb-4 border-2 border-amber-200">
                        ` : ''}
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-gray-600">Gross Weight</p>
                                <p class="font-semibold text-gray-800">${loan.gross_weight}g</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Stone Weight</p>
                                <p class="font-semibold text-gray-800">${loan.stone_weight}g</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Net Weight</p>
                                <p class="font-semibold text-amber-600">${loan.net_weight}g</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Purity</p>
                                <p class="font-semibold text-amber-600">${loan.purity}</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Gold Rate</p>
                                <p class="font-semibold text-gray-800">${formatCurrency(loan.gold_rate_per_gram)}/g</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">LTV %</p>
                                <p class="font-semibold text-gray-800">${loan.ltv_percentage}%</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Transaction History -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-history text-amber-500 mr-2"></i>Transaction History
                        </h3>
                        ${transactions && transactions.length > 0 ? `
                            <div class="space-y-3">
                                ${transactions.map(txn => `
                                    <div class="border-l-4 border-green-500 bg-green-50 rounded-lg p-4">
                                        <div class="flex items-center justify-between">
                                            <div>
                                                <p class="font-semibold text-gray-800">${txn.transaction_type.toUpperCase()} Payment</p>
                                                <p class="text-sm text-gray-600">${formatDate(txn.payment_date)} • ${txn.payment_method}</p>
                                            </div>
                                            <div class="text-right">
                                                <p class="font-bold text-green-700">${formatCurrency(txn.amount)}</p>
                                                <p class="text-xs text-gray-600">I: ${formatCurrency(txn.interest_paid)} | P: ${formatCurrency(txn.principal_paid)}</p>
                                            </div>
                                        </div>
                                        ${txn.notes ? `<p class="text-sm text-gray-600 mt-2">${txn.notes}</p>` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        ` : '<p class="text-center text-gray-500 py-4">No transactions yet</p>'}
                    </div>
                </div>
                
                <!-- Sidebar Actions -->
                <div class="space-y-6">
                    <!-- Make Payment -->
                    ${loan.status === 'active' ? `
                        <div class="bg-white rounded-xl shadow-lg p-6 sticky top-20">
                            <h3 class="text-xl font-bold text-gray-800 mb-4">
                                <i class="fas fa-credit-card text-amber-500 mr-2"></i>Make Payment
                            </h3>
                            
                            <form onsubmit="handlePayment(event, ${loan.id})">
                                <div class="space-y-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Payment Type</label>
                                        <select id="paymentType" onchange="updatePaymentAmount()" required
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                            <option value="">Select Type</option>
                                            <option value="interest">Interest Only (${formatCurrency(interest)})</option>
                                            <option value="principal">Principal Only</option>
                                            <option value="partial">Partial Payment</option>
                                            <option value="full">Full Settlement (${formatCurrency(totalDue)})</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Amount (₹)</label>
                                        <input type="number" id="paymentAmount" required step="0.01" min="0"
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                                        <select id="paymentMethod" required
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                            <option value="cash">Cash</option>
                                            <option value="upi">UPI</option>
                                            <option value="card">Card</option>
                                            <option value="bank_transfer">Bank Transfer</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Payment Date</label>
                                        <input type="date" id="paymentDate" required value="${new Date().toISOString().split('T')[0]}"
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                                        <textarea id="paymentNotes" rows="2"
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"></textarea>
                                    </div>
                                    
                                    <button type="submit"
                                        class="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 rounded-lg hover:shadow-lg transition-all">
                                        <i class="fas fa-check-circle mr-2"></i>Record Payment
                                    </button>
                                </div>
                            </form>
                        </div>
                    ` : ''}
                    
                    <!-- Quick Actions -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <button onclick="downloadLoanPDF(${loan.id})"
                                class="w-full px-4 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all">
                                <i class="fas fa-file-pdf mr-2"></i>Download PDF
                            </button>
                            <button onclick="printLoan(${loan.id})"
                                class="w-full px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all">
                                <i class="fas fa-print mr-2"></i>Print
                            </button>
                            ${loan.status === 'active' ? `
                                <button onclick="closeLoan(${loan.id})"
                                    class="w-full px-4 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all">
                                    <i class="fas fa-lock mr-2"></i>Close Loan
                                </button>
                            ` : ''}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

window.updatePaymentAmount = () => {
    const type = document.getElementById('paymentType')?.value;
    const loan = AppState.selectedLoan?.loan;
    if (!loan || !type) return;
    
    const interest = calculateInterest(loan);
    const amountField = document.getElementById('paymentAmount');
    
    if (type === 'interest') {
        amountField.value = interest;
    } else if (type === 'full') {
        amountField.value = loan.principal_remaining + interest;
    } else {
        amountField.value = '';
    }
};

window.handlePayment = async (e, loanId) => {
    e.preventDefault();
    
    const paymentData = {
        loan_id: loanId,
        transaction_type: document.getElementById('paymentType').value,
        amount: parseFloat(document.getElementById('paymentAmount').value),
        payment_method: document.getElementById('paymentMethod').value,
        payment_date: document.getElementById('paymentDate').value,
        notes: document.getElementById('paymentNotes').value
    };
    
    try {
        const res = await api.post('/payments', paymentData);
        
        showSuccess('Payment recorded successfully!');
        
        // Reload loan details
        await loadLoanDetails(loanId);
    } catch (error) {
        console.error('Payment error:', error);
        showError(error.response?.data?.error || 'Payment failed');
    }
};

window.closeLoan = async (loanId) => {
    if (!confirm('Are you sure you want to close this loan? This action cannot be undone.')) {
        return;
    }
    
    try {
        await api.patch(`/loans/${loanId}/status`, { status: 'closed' });
        showSuccess('Loan closed successfully!');
        await loadLoanDetails(loanId);
    } catch (error) {
        showError('Failed to close loan');
    }
};

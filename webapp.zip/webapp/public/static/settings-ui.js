// ============ SETTINGS UI ============
function renderSettings() {
    const settings = AppState.settings || {};
    
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <h1 class="text-4xl font-bold text-gray-800 mb-8">
                <i class="fas fa-cog text-amber-500 mr-3"></i>Shop Settings
            </h1>
            
            <div class="bg-white rounded-xl shadow-lg p-8">
                <form onsubmit="handleSettingsUpdate(event)" class="space-y-8">
                    <!-- Shop Logo -->
                    <div class="border-b pb-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-image text-amber-500 mr-2"></i>Shop Logo
                        </h3>
                        <div class="flex items-center space-x-6">
                            ${settings.shop_logo_url ? `
                                <img src="${settings.shop_logo_url}" alt="Shop Logo" class="w-32 h-32 object-contain border-2 border-gray-200 rounded-lg">
                            ` : '<div class="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center"><i class="fas fa-image text-gray-400 text-3xl"></i></div>'}
                            <div>
                                <button type="button" onclick="uploadLogo()" 
                                    class="px-6 py-3 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-all">
                                    <i class="fas fa-upload mr-2"></i>Upload Logo
                                </button>
                                <input type="file" id="logoFile" accept="image/*" class="hidden" onchange="handleLogoUpload()">
                                <p class="text-sm text-gray-600 mt-2">Recommended: 500x500px, PNG with transparent background</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- UPI Details -->
                    <div class="border-b pb-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-mobile-alt text-amber-500 mr-2"></i>UPI Payment Details
                        </h3>
                        <div class="grid grid-cols-1 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">UPI ID</label>
                                <input type="text" id="upiId" value="${settings.upi_id || ''}"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                    placeholder="yourshop@upi">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Bank Details -->
                    <div class="border-b pb-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-university text-amber-500 mr-2"></i>Bank Account Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Bank Name</label>
                                <input type="text" id="bankName" value="${settings.bank_name || ''}"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                    placeholder="State Bank of India">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Account Number</label>
                                <input type="text" id="accountNumber" value="${settings.account_number || ''}"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                    placeholder="1234567890">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">IFSC Code</label>
                                <input type="text" id="ifscCode" value="${settings.ifsc_code || ''}"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                    placeholder="SBIN0001234">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Branch</label>
                                <input type="text" id="branch" value="${settings.branch || ''}"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                                    placeholder="Main Branch">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment QR Code -->
                    <div class="border-b pb-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">
                            <i class="fas fa-qrcode text-amber-500 mr-2"></i>Payment QR Code
                        </h3>
                        <div class="flex items-center space-x-6">
                            ${settings.payment_qr_code_url ? `
                                <img src="${settings.payment_qr_code_url}" alt="QR Code" class="w-48 h-48 object-contain border-2 border-gray-200 rounded-lg">
                            ` : '<div class="w-48 h-48 bg-gray-100 rounded-lg flex items-center justify-center"><i class="fas fa-qrcode text-gray-400 text-5xl"></i></div>'}
                            <div>
                                <button type="button" onclick="uploadQR()" 
                                    class="px-6 py-3 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-all">
                                    <i class="fas fa-upload mr-2"></i>Upload QR Code
                                </button>
                                <input type="file" id="qrFile" accept="image/*" class="hidden" onchange="handleQRUpload()">
                                <p class="text-sm text-gray-600 mt-2">Upload your UPI payment QR code for PDF invoices</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <div class="flex space-x-4">
                        <button type="submit" 
                            class="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold py-4 rounded-lg hover:shadow-lg transition-all">
                            <i class="fas fa-save mr-2"></i>Save Settings
                        </button>
                        <button type="button" onclick="showView('audit')"
                            class="px-8 py-4 border-2 border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition-all">
                            <i class="fas fa-shield-alt mr-2"></i>View Audit Logs
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
}

window.uploadLogo = () => {
    document.getElementById('logoFile').click();
};

window.uploadQR = () => {
    document.getElementById('qrFile').click();
};

let settingsImages = {
    logo: null,
    qr: null
};

window.handleLogoUpload = async () => {
    const file = document.getElementById('logoFile').files[0];
    if (!file) return;
    
    try {
        const compressed = await compressImage(file, 0.3);
        settingsImages.logo = compressed;
        showSuccess('Logo uploaded successfully');
        
        // Update settings immediately
        const url = await uploadFile(compressed, 'logo');
        await api.patch('/settings', { shop_logo_url: url });
        await loadSettings();
    } catch (error) {
        showError('Failed to upload logo');
    }
};

window.handleQRUpload = async () => {
    const file = document.getElementById('qrFile').files[0];
    if (!file) return;
    
    try {
        const compressed = await compressImage(file, 0.3);
        settingsImages.qr = compressed;
        showSuccess('QR code uploaded successfully');
        
        // Update settings immediately
        const url = await uploadFile(compressed, 'qr');
        await api.patch('/settings', { payment_qr_code_url: url });
        await loadSettings();
    } catch (error) {
        showError('Failed to upload QR code');
    }
};

window.handleSettingsUpdate = async (e) => {
    e.preventDefault();
    
    const settingsData = {
        upi_id: document.getElementById('upiId').value,
        bank_name: document.getElementById('bankName').value,
        account_number: document.getElementById('accountNumber').value,
        ifsc_code: document.getElementById('ifscCode').value,
        branch: document.getElementById('branch').value
    };
    
    try {
        await api.patch('/settings', settingsData);
        showSuccess('Settings saved successfully!');
        await loadSettings();
    } catch (error) {
        showError('Failed to save settings');
    }
};

// ============ LOANS LIST UI ============
function renderLoans() {
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-7xl">
            <h1 class="text-4xl font-bold text-gray-800 mb-8">
                <i class="fas fa-file-invoice-dollar text-amber-500 mr-3"></i>All Loans
            </h1>
            
            <!-- Filters -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                        <input type="text" id="searchInput" placeholder="Name, Phone, Loan ID..."
                            onchange="applyFilters()"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select id="statusFilter" onchange="applyFilters()"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                            <option value="all">All Status</option>
                            <option value="active">Active</option>
                            <option value="closed">Closed</option>
                            <option value="overdue">Overdue</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                        <input type="date" id="startDateFilter" onchange="applyFilters()"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                        <input type="date" id="endDateFilter" onchange="applyFilters()"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500">
                    </div>
                </div>
                <div class="flex justify-end mt-4">
                    <button onclick="resetFilters()" class="text-amber-600 hover:text-amber-700 font-semibold">
                        <i class="fas fa-redo mr-2"></i>Reset Filters
                    </button>
                </div>
            </div>
            
            <!-- Loans Table -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                            <tr>
                                <th class="text-left py-4 px-4 font-semibold">Loan #</th>
                                <th class="text-left py-4 px-4 font-semibold">Customer</th>
                                <th class="text-left py-4 px-4 font-semibold">Date</th>
                                <th class="text-left py-4 px-4 font-semibold">Days</th>
                                <th class="text-left py-4 px-4 font-semibold">Principal</th>
                                <th class="text-left py-4 px-4 font-semibold">Interest</th>
                                <th class="text-left py-4 px-4 font-semibold">Total Due</th>
                                <th class="text-left py-4 px-4 font-semibold">Status</th>
                                <th class="text-left py-4 px-4 font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${AppState.loans.map(loan => `
                                <tr class="border-b border-gray-100 hover:bg-amber-50 transition-colors">
                                    <td class="py-4 px-4 font-medium text-gray-900">${loan.loan_number}</td>
                                    <td class="py-4 px-4">
                                        <div class="font-medium text-gray-900">${loan.customer_name}</div>
                                        <div class="text-sm text-gray-600">${loan.customer_phone}</div>
                                    </td>
                                    <td class="py-4 px-4 text-gray-700">${formatDate(loan.loan_date)}</td>
                                    <td class="py-4 px-4">
                                        <span class="font-semibold ${loan.days_elapsed > 90 ? 'text-red-600' : 'text-gray-700'}">
                                            ${loan.days_elapsed}
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 font-semibold text-blue-600">${formatCurrency(loan.principal_remaining)}</td>
                                    <td class="py-4 px-4 font-semibold text-green-600">${formatCurrency(loan.interest_due)}</td>
                                    <td class="py-4 px-4 font-bold text-purple-600">${formatCurrency(loan.total_amount_due)}</td>
                                    <td class="py-4 px-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                                            ${loan.status === 'active' ? 'bg-green-100 text-green-700' : 
                                              loan.status === 'closed' ? 'bg-gray-100 text-gray-700' : 
                                              'bg-red-100 text-red-700'}">
                                            ${loan.status.toUpperCase()}
                                        </span>
                                        ${isOverdue(loan) ? '<div class="text-xs text-red-600 mt-1 font-semibold">⚠️ OVERDUE</div>' : ''}
                                    </td>
                                    <td class="py-4 px-4">
                                        <div class="flex space-x-2">
                                            <button onclick="loadLoanDetails(${loan.id})" 
                                                class="text-amber-600 hover:text-amber-700" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button onclick="downloadLoanPDF(${loan.id})" 
                                                class="text-red-600 hover:text-red-700" title="PDF">
                                                <i class="fas fa-file-pdf"></i>
                                            </button>
                                            <button onclick="openWhatsApp('${loan.customer_phone}', '${loan.customer_name}', '${loan.loan_number}', ${loan.interest_due})"
                                                class="text-green-600 hover:text-green-700" title="WhatsApp">
                                                <i class="fab fa-whatsapp"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    ${AppState.loans.length === 0 ? `
                        <div class="text-center py-12">
                            <i class="fas fa-inbox text-gray-300 text-6xl mb-4"></i>
                            <p class="text-gray-500 text-lg">No loans found</p>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

window.applyFilters = () => {
    AppState.filters = {
        search: document.getElementById('searchInput')?.value || '',
        status: document.getElementById('statusFilter')?.value || 'all',
        startDate: document.getElementById('startDateFilter')?.value || '',
        endDate: document.getElementById('endDateFilter')?.value || ''
    };
    loadLoans(AppState.filters);
};

window.resetFilters = () => {
    if (document.getElementById('searchInput')) document.getElementById('searchInput').value = '';
    if (document.getElementById('statusFilter')) document.getElementById('statusFilter').value = 'all';
    if (document.getElementById('startDateFilter')) document.getElementById('startDateFilter').value = '';
    if (document.getElementById('endDateFilter')) document.getElementById('endDateFilter').value = '';
    applyFilters();
};

// ============ CUSTOMERS UI ============
function renderCustomers() {
    document.getElementById('app').innerHTML = `
        ${renderNavbar()}
        
        <div class="container mx-auto px-4 py-8 max-w-7xl">
            <h1 class="text-4xl font-bold text-gray-800 mb-8">
                <i class="fas fa-users text-amber-500 mr-3"></i>Customers
            </h1>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                ${AppState.customers.map(customer => `
                    <div class="bg-white rounded-xl shadow-lg p-6 card-hover">
                        <div class="flex items-center space-x-4 mb-4">
                            ${customer.customer_photo_url ? `
                                <img src="${customer.customer_photo_url}" alt="${customer.name}" 
                                    class="w-16 h-16 rounded-full object-cover">
                            ` : `
                                <div class="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center">
                                    <span class="text-white text-2xl font-bold">${customer.name.charAt(0)}</span>
                                </div>
                            `}
                            <div>
                                <h3 class="text-lg font-bold text-gray-800">${customer.name}</h3>
                                <p class="text-sm text-gray-600">${customer.phone}</p>
                            </div>
                        </div>
                        ${customer.address ? `<p class="text-sm text-gray-600 mb-4"><i class="fas fa-map-marker-alt mr-2"></i>${customer.address}</p>` : ''}
                        <div class="flex space-x-2">
                            <button onclick="viewCustomerLoans(${customer.id})" 
                                class="flex-1 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-all">
                                <i class="fas fa-file-invoice-dollar mr-2"></i>View Loans
                            </button>
                            <button onclick="openWhatsApp('${customer.phone}', '${customer.name}', '', 0)"
                                class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all">
                                <i class="fab fa-whatsapp"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            ${AppState.customers.length === 0 ? `
                <div class="text-center py-12">
                    <i class="fas fa-users text-gray-300 text-6xl mb-4"></i>
                    <p class="text-gray-500 text-lg">No customers found</p>
                </div>
            ` : ''}
        </div>
    `;
}

window.viewCustomerLoans = (customerId) => {
    AppState.filters = { ...AppState.filters, search: `customer:${customerId}` };
    showView('loans');
};

// ============ AUDIT LOGS ============
async function loadAuditLogs() {
    try {
        const res = await api.get('/audit');
        const logs = res.data.logs || [];
        
        document.getElementById('app').innerHTML = `
            ${renderNavbar()}
            
            <div class="container mx-auto px-4 py-8 max-w-7xl">
                <h1 class="text-4xl font-bold text-gray-800 mb-8">
                    <i class="fas fa-shield-alt text-amber-500 mr-3"></i>Audit Logs
                </h1>
                
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700">Time</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700">Action</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700">Entity</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700">Details</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700">IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${logs.map(log => `
                                    <tr class="border-b border-gray-100 hover:bg-gray-50">
                                        <td class="py-3 px-4 text-sm text-gray-700">${formatDate(log.created_at)}</td>
                                        <td class="py-3 px-4">
                                            <span class="px-2 py-1 rounded text-xs font-semibold bg-amber-100 text-amber-700">
                                                ${log.action}
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 text-sm text-gray-700">${log.entity_type}</td>
                                        <td class="py-3 px-4 text-sm text-gray-600">${log.new_values || '-'}</td>
                                        <td class="py-3 px-4 text-sm text-gray-600">${log.ip_address || '-'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (error) {
        showError('Failed to load audit logs');
    }
}

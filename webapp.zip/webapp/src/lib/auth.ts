// src/lib/auth.ts
// ------------------------------------
// Authentication & Authorization
// Cloudflare Workers + Hono
// ------------------------------------

import { Context } from 'hono'
import jwt from '@tsndr/cloudflare-worker-jwt'
import bcrypt from 'bcryptjs'
import { db } from './db'

// -------------------------------
// Generate JWT
// -------------------------------
export async function generateToken(
  tenantId: number,
  email: string,
  secret: string
) {
  return await jwt.sign(
    {
      tenant_id: tenantId,
      email
    },
    secret,
    {
      expiresIn: '1h' // SHORT-LIVED TOKEN (SECURE)
    }
  )
}

// -------------------------------
// Verify JWT Middleware
// -------------------------------
export async function authMiddleware(c: Context, next: Function) {
  const authHeader = c.req.header('Authorization')

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ error: 'Unauthorized' }, 401)
  }

  const token = authHeader.replace('Bearer ', '')
  const secret = c.env.JWT_SECRET

  if (!secret) {
    console.error('JWT_SECRET not configured')
    return c.json({ error: 'Server configuration error' }, 500)
  }

  const isValid = await jwt.verify(token, secret)

  if (!isValid) {
    return c.json({ error: 'Invalid token' }, 401)
  }

  const payload = jwt.decode(token)

  c.set('tenant_id', payload.tenant_id)
  c.set('email', payload.email)

  await next()
}

// -------------------------------
// Get Tenant ID from Context
// -------------------------------
export function getTenantId(c: Context): number {
  const tenantId = c.get('tenant_id')
  if (!tenantId) {
    throw new Error('Tenant not authenticated')
  }
  return tenantId
}

// -------------------------------
// Password Utilities
// -------------------------------
export async function hashPassword(password: string) {
  return await bcrypt.hash(password, 10)
}

export async function verifyPassword(
  password: string,
  hash: string
) {
  return await bcrypt.compare(password, hash)
}

// -------------------------------
// Login Helper
// -------------------------------
export async function authenticateTenant(
  email: string,
  password: string,
  jwtSecret: string
) {
  const tenant = await db.get(
    `
    SELECT id, email, password_hash, is_active
    FROM tenants
    WHERE email = ?
    `,
    [email]
  )

  if (!tenant || tenant.is_active !== 1) {
    return null
  }

  const isValidPassword = await verifyPassword(
    password,
    tenant.password_hash
  )

  if (!isValidPassword) {
    return null
  }

  const token = await generateToken(
    tenant.id,
    tenant.email,
    jwtSecret
  )

  return {
    token,
    tenant_id: tenant.id,
    email: tenant.email
  }
}
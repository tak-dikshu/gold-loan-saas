// lib/loan-utils.ts
// ------------------------------------
// Core financial utility functions
// Gold Loan Management SaaS
// ------------------------------------

/**
 * Returns purity multiplier based on gold purity
 */
export function getPurityFactor(purity: string): number {
  switch (purity) {
    case '24K':
      return 1
    case '22K':
      return 0.9167
    case '18K':
      return 0.75
    default:
      // Fallback safety (should never happen)
      return 1
  }
}

/**
 * Calculates loan amount based on:
 * net weight × gold rate × purity × LTV%
 */
export function calculateLoanAmount({
  netWeight,
  purity,
  goldRatePerGram,
  ltvPercentage
}: {
  netWeight: number
  purity: string
  goldRatePerGram: number
  ltvPercentage: number
}): number {
  const purityFactor = getPurityFactor(purity)
  const goldValue = netWeight * goldRatePerGram * purityFactor
  const loanAmount = (goldValue * ltvPercentage) / 100

  // Return rounded to 2 decimals
  return +loanAmount.toFixed(2)
}

/**
 * Accrues interest ONLY from the last interest calculation date
 * This is audit-safe and prevents overcharging
 *
 * Formula:
 * (outstandingPrincipal × monthlyRate × days) / (100 × 30)
 */
export function accrueInterest({
  outstandingPrincipal,
  lastInterestCalculatedAt,
  asOfDate,
  rate30,
  rate60,
  rate90
}: {
  outstandingPrincipal: number
  lastInterestCalculatedAt: string
  asOfDate: string
  rate30: number
  rate60: number
  rate90: number
}): number {
  // No principal = no interest
  if (outstandingPrincipal <= 0) return 0

  const startDate = new Date(lastInterestCalculatedAt)
  const endDate = new Date(asOfDate)

  const daysDifference = Math.floor(
    (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
  )

  // Same day or invalid date range
  if (daysDifference <= 0) return 0

  // Determine slab rate
  let applicableRate = rate30
  if (daysDifference > 60) {
    applicableRate = rate90
  } else if (daysDifference > 30) {
    applicableRate = rate60
  }

  const interest =
    (outstandingPrincipal * applicableRate * daysDifference) / (100 * 30)

  // Round to 2 decimals
  return +interest.toFixed(2)
}
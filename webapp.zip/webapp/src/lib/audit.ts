import type { Context } from 'hono';
import type { Bindings } from '../types';

export async function logAudit(
  c: Context<{ Bindings: Bindings }>,
  action: string,
  entityType: string,
  entityId?: number,
  oldValues?: any,
  newValues?: any
) {
  const tenantId = c.get('tenantId') as number;
  const userId = tenantId; // In this system, tenant is the user
  
  const ipAddress = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
  const userAgent = c.req.header('User-Agent') || 'unknown';
  
  try {
    await c.env.DB.prepare(`
      INSERT INTO audit_logs (tenant_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      tenantId,
      userId,
      action,
      entityType,
      entityId || null,
      oldValues ? JSON.stringify(oldValues) : null,
      newValues ? JSON.stringify(newValues) : null,
      ipAddress,
      userAgent
    ).run();
  } catch (error) {
    console.error('Failed to log audit:', error);
  }
}

export async function getAuditLogs(
  c: Context<{ Bindings: Bindings }>,
  limit: number = 100,
  offset: number = 0
) {
  const tenantId = c.get('tenantId') as number;
  
  const result = await c.env.DB.prepare(`
    SELECT * FROM audit_logs
    WHERE tenant_id = ?
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
  `).bind(tenantId, limit, offset).all();
  
  return result.results;
}

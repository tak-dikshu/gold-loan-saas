import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { serveStatic } from 'hono/cloudflare-workers';
import type { Bindings } from './types';

// Import routes
import authRoutes from './routes/auth';
import loanRoutes from './routes/loans';
import paymentRoutes from './routes/payments';
import customerRoutes from './routes/customers';
import settingsRoutes from './routes/settings';
import auditRoutes from './routes/audit';

const app = new Hono<{ Bindings: Bindings }>();

// Enable CORS
app.use('/api/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// API Routes
app.route('/api/auth', authRoutes);
app.route('/api/loans', loanRoutes);
app.route('/api/payments', paymentRoutes);
app.route('/api/customers', customerRoutes);
app.route('/api/settings', settingsRoutes);
app.route('/api/audit', auditRoutes);

// Storage route for serving uploaded files
app.get('/api/storage/*', async (c) => {
  const path = c.req.param('*');
  
  try {
    const object = await c.env.STORAGE.get(path);
    
    if (!object) {
      return c.notFound();
    }
    
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('Cache-Control', 'public, max-age=31536000');
    
    return new Response(object.body, { headers });
  } catch (error: any) {
    return c.json({ error: 'File not found' }, 404);
  }
});

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }));

// Main app route
app.get('/*', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Gold Loan Management System for Jewelers">
    <title>Gold Loan Management SaaS</title>
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#F59E0B">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Gold Loan SaaS">
    <link rel="manifest" href="/static/manifest.json">
    <link rel="icon" href="/static/icon-192.png">
    <link rel="apple-touch-icon" href="/static/icon-512.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Date-fns -->
    <script src="https://cdn.jsdelivr.net/npm/date-fns@3.0.0/cdn.min.js"></script>
    
    <!-- Custom Styles -->
    <link href="/static/styles.css" rel="stylesheet">
    
    <style>
        @keyframes pulse-red {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .pulse-red {
            animation: pulse-red 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-amber-50 to-orange-100 min-h-screen">
    <div id="app"></div>
    
    <!-- Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/browser-image-compression@2.0.2/dist/browser-image-compression.js"></script>
    
    <!-- Main App -->
    <script src="/static/app.js" type="module"></script>
</body>
</html>`);
});

export default app;

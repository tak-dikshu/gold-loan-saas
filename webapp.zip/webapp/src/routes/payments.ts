// routes/payments.ts
// ------------------------------------
// Payment handling routes
// Gold Loan Management SaaS
// ------------------------------------

import { Hono } from 'hono'
import { getTenantId } from '../lib/auth'
import { accrueInterest } from '../lib/loan-utils'
import { db } from '../lib/db'

const payments = new Hono()

// -------------------------------
// Record Payment
// -------------------------------
payments.post('/', async (c) => {
  try {
    const tenantId = getTenantId(c)
    const body = await c.req.json()

    const {
      loan_id,
      amount,
      payment_method = 'cash',
      payment_date,
      notes
    } = body

    if (!loan_id || !amount || amount <= 0) {
      return c.json({ error: 'Invalid payment data' }, 400)
    }

    // -------------------------------
    // Fetch Loan
    // -------------------------------
    const loan = await db.get(
      `
      SELECT * FROM loans
      WHERE id = ? AND tenant_id = ?
      `,
      [loan_id, tenantId]
    )

    if (!loan) {
      return c.json({ error: 'Loan not found' }, 404)
    }

    const paymentDate =
      payment_date ?? new Date().toISOString().split('T')[0]

    // -------------------------------
    // Accrue Interest Till Payment Date
    // -------------------------------
    const newlyAccrued = accrueInterest({
      outstandingPrincipal: loan.outstanding_principal,
      lastInterestCalculatedAt:
        loan.last_interest_calculated_at ?? loan.loan_date,
      asOfDate: paymentDate,
      rate30: loan.interest_rate_30,
      rate60: loan.interest_rate_60,
      rate90: loan.interest_rate_90
    })

    let accruedInterest = loan.accrued_interest + newlyAccrued

    // -------------------------------
    // Apply Payment (Interest First)
    // -------------------------------
    let remainingAmount = amount
    let interestPaid = 0
    let principalPaid = 0

    if (accruedInterest > 0) {
      interestPaid = Math.min(accruedInterest, remainingAmount)
      accruedInterest -= interestPaid
      remainingAmount -= interestPaid
    }

    if (remainingAmount > 0) {
      principalPaid = Math.min(
        loan.outstanding_principal,
        remainingAmount
      )
      remainingAmount -= principalPaid
    }

    const newOutstandingPrincipal =
      loan.outstanding_principal - principalPaid

    // -------------------------------
    // Update Loan State
    // -------------------------------
    await db.run(
      `
      UPDATE loans SET
        accrued_interest = ?,
        outstanding_principal = ?,
        last_interest_calculated_at = ?,
        last_payment_date = ?
      WHERE id = ? AND tenant_id = ?
      `,
      [
        accruedInterest,
        newOutstandingPrincipal,
        paymentDate,
        paymentDate,
        loan.id,
        tenantId
      ]
    )

    // -------------------------------
    // Insert Transaction Record
    // -------------------------------
    await db.run(
      `
      INSERT INTO transactions (
        tenant_id,
        loan_id,
        transaction_type,
        amount,
        interest_paid,
        principal_paid,
        payment_method,
        payment_date,
        notes
      ) VALUES (?, ?, 'partial', ?, ?, ?, ?, ?, ?)
      `,
      [
        tenantId,
        loan.id,
        amount,
        interestPaid,
        principalPaid,
        payment_method,
        paymentDate,
        notes ?? null
      ]
    )

    // -------------------------------
    // Auto-Close Loan if Fully Paid
    // -------------------------------
    if (newOutstandingPrincipal <= 0 && accruedInterest <= 0) {
      await db.run(
        `
        UPDATE loans
        SET status = 'closed', closed_date = ?
        WHERE id = ?
        `,
        [paymentDate, loan.id]
      )
    }

    return c.json(
      {
        message: 'Payment recorded successfully',
        interest_paid: interestPaid,
        principal_paid: principalPaid,
        outstanding_principal: newOutstandingPrincipal,
        accrued_interest: accruedInterest
      },
      201
    )

  } catch (error: any) {
    console.error('Payment error:', error)
    return c.json({ error: 'Failed to record payment' }, 500)
  }
})

export default payments
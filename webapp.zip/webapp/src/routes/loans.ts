// routes/loans.ts
// ------------------------------------
// Loan creation and management routes
// Gold Loan Management SaaS
// ------------------------------------

import { Hono } from 'hono'
import { getTenantId } from '../lib/auth'
import { calculateLoanAmount } from '../lib/loan-utils'
import { db } from '../lib/db'

const loans = new Hono()

// -------------------------------
// Create New Loan
// -------------------------------
loans.post('/', async (c) => {
  try {
    const tenantId = getTenantId(c)
    const body = await c.req.json()

    const {
      customer_id,
      loan_number,
      product_photo_url,
      gross_weight,
      stone_weight = 0,
      net_weight,
      purity,
      gold_rate_per_gram,
      ltv_percentage = 75,
      interest_rate_30 = 1.5,
      interest_rate_60 = 2.0,
      interest_rate_90 = 2.5,
      loan_date
    } = body

    // -------------------------------
    // Basic Validation
    // -------------------------------
    if (
      !customer_id ||
      !loan_number ||
      !gross_weight ||
      !net_weight ||
      !purity ||
      !gold_rate_per_gram
    ) {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    // -------------------------------
    // Calculate Loan Amount (Server-side)
    // -------------------------------
    const loanAmount = calculateLoanAmount({
      netWeight: net_weight,
      purity,
      goldRatePerGram: gold_rate_per_gram,
      ltvPercentage: ltv_percentage
    })

    const loanDate =
      loan_date ?? new Date().toISOString().split('T')[0]

    // -------------------------------
    // Insert Loan (Correct Financial State)
    // -------------------------------
    await db.run(
      `
      INSERT INTO loans (
        tenant_id,
        customer_id,
        loan_number,
        product_photo_url,
        gross_weight,
        stone_weight,
        net_weight,
        purity,
        gold_rate_per_gram,
        ltv_percentage,
        loan_amount,
        outstanding_principal,
        accrued_interest,
        last_interest_calculated_at,
        interest_rate_30,
        interest_rate_60,
        interest_rate_90,
        status,
        loan_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 'active', ?)
      `,
      [
        tenantId,
        customer_id,
        loan_number,
        product_photo_url ?? null,
        gross_weight,
        stone_weight,
        net_weight,
        purity,
        gold_rate_per_gram,
        ltv_percentage,
        loanAmount,
        loanAmount, // outstanding_principal
        loanDate,   // last_interest_calculated_at
        interest_rate_30,
        interest_rate_60,
        interest_rate_90,
        loanDate
      ]
    )

    return c.json({
      message: 'Loan created successfully',
      loan_amount: loanAmount,
      outstanding_principal: loanAmount
    }, 201)

  } catch (error: any) {
    console.error('Create loan error:', error)
    return c.json({ error: 'Failed to create loan' }, 500)
  }
})

export default loans
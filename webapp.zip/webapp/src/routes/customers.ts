import { Hono } from 'hono';
import type { Bindings } from '../types';
import { authMiddleware, getTenantId } from '../lib/auth';
import { logAudit } from '../lib/audit';

const customers = new Hono<{ Bindings: Bindings }>();

// Apply auth middleware
customers.use('/*', authMiddleware);

// Get all customers
customers.get('/', async (c) => {
  const tenantId = getTenantId(c);
  const search = c.req.query('search');
  
  let query = 'SELECT * FROM customers WHERE tenant_id = ?';
  const params: any[] = [tenantId];
  
  if (search) {
    query += ' AND (name LIKE ? OR phone LIKE ?)';
    const searchParam = `%${search}%`;
    params.push(searchParam, searchParam);
  }
  
  query += ' ORDER BY created_at DESC';
  
  const result = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json({ customers: result.results });
});

// Get single customer with loan history
customers.get('/:id', async (c) => {
  const tenantId = getTenantId(c);
  const customerId = c.req.param('id');
  
  const customer = await c.env.DB.prepare(
    'SELECT * FROM customers WHERE id = ? AND tenant_id = ?'
  ).bind(customerId, tenantId).first();
  
  if (!customer) {
    return c.json({ error: 'Customer not found' }, 404);
  }
  
  // Get loan history
  const loans = await c.env.DB.prepare(`
    SELECT * FROM loans
    WHERE customer_id = ? AND tenant_id = ?
    ORDER BY loan_date DESC
  `).bind(customerId, tenantId).all();
  
  return c.json({
    customer,
    loans: loans.results
  });
});

// Create customer
customers.post('/', async (c) => {
  const tenantId = getTenantId(c);
  
  try {
    const {
      name,
      phone,
      address,
      id_proof_type,
      id_proof_number,
      customer_photo_url
    } = await c.req.json();
    
    if (!name || !phone) {
      return c.json({ error: 'Name and phone are required' }, 400);
    }
    
    const result = await c.env.DB.prepare(`
      INSERT INTO customers (tenant_id, name, phone, address, id_proof_type, id_proof_number, customer_photo_url)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      tenantId,
      name,
      phone,
      address || null,
      id_proof_type || null,
      id_proof_number || null,
      customer_photo_url || null
    ).run();
    
    const customerId = result.meta.last_row_id as number;
    
    await logAudit(c, 'CREATE', 'customer', customerId, null, { name, phone });
    
    return c.json({
      success: true,
      customer_id: customerId
    }, 201);
  } catch (error: any) {
    console.error('Customer creation error:', error);
    return c.json({ error: 'Failed to create customer', details: error.message }, 500);
  }
});

// Update customer
customers.patch('/:id', async (c) => {
  const tenantId = getTenantId(c);
  const customerId = c.req.param('id');
  
  try {
    const oldCustomer = await c.env.DB.prepare(
      'SELECT * FROM customers WHERE id = ? AND tenant_id = ?'
    ).bind(customerId, tenantId).first();
    
    if (!oldCustomer) {
      return c.json({ error: 'Customer not found' }, 404);
    }
    
    const updates = await c.req.json();
    const allowedFields = ['name', 'phone', 'address', 'id_proof_type', 'id_proof_number', 'customer_photo_url'];
    
    const setClause = [];
    const params = [];
    
    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        setClause.push(`${field} = ?`);
        params.push(updates[field]);
      }
    }
    
    if (setClause.length === 0) {
      return c.json({ error: 'No fields to update' }, 400);
    }
    
    setClause.push('updated_at = CURRENT_TIMESTAMP');
    params.push(customerId, tenantId);
    
    await c.env.DB.prepare(`
      UPDATE customers
      SET ${setClause.join(', ')}
      WHERE id = ? AND tenant_id = ?
    `).bind(...params).run();
    
    await logAudit(c, 'UPDATE', 'customer', Number(customerId), oldCustomer, updates);
    
    return c.json({ success: true });
  } catch (error: any) {
    console.error('Customer update error:', error);
    return c.json({ error: 'Failed to update customer', details: error.message }, 500);
  }
});

export default customers;

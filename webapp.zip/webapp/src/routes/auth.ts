// src/routes/auth.ts
// ------------------------------------
// Auth routes: Register & Login
// ------------------------------------

import { Hono } from 'hono'
import { db } from '../lib/db'
import {
  hashPassword,
  authenticateTenant
} from '../lib/auth'

const auth = new Hono()

// -------------------------------
// Register (Create Tenant)
// -------------------------------
auth.post('/register', async (c) => {
  const body = await c.req.json()
  const {
    shop_name,
    email,
    password,
    phone,
    address
  } = body

  if (!shop_name || !email || !password) {
    return c.json({ error: 'Missing required fields' }, 400)
  }

  try {
    const passwordHash = await hashPassword(password)

    await db.run(
      `
      INSERT INTO tenants (
        shop_name,
        email,
        password_hash,
        phone,
        address,
        is_active
      ) VALUES (?, ?, ?, ?, ?, 1)
      `,
      [
        shop_name,
        email,
        passwordHash,
        phone ?? null,
        address ?? null
      ]
    )

    return c.json(
      { message: 'Registration successful' },
      201
    )

  } catch (error: any) {
    console.error('Register error:', error)

    // SQLite / D1 safe duplicate email handling
    return c.json(
      { error: 'Email already registered or invalid data' },
      409
    )
  }
})

// -------------------------------
// Login
// -------------------------------
auth.post('/login', async (c) => {
  const body = await c.req.json()
  const { email, password } = body

  if (!email || !password) {
    return c.json(
      { error: 'Invalid email or password' },
      400
    )
  }

  const jwtSecret = c.env.JWT_SECRET
  if (!jwtSecret) {
    console.error('JWT_SECRET not configured')
    return c.json(
      { error: 'Server configuration error' },
      500
    )
  }

  const result = await authenticateTenant(
    email,
    password,
    jwtSecret
  )

  if (!result) {
    return c.json(
      { error: 'Invalid email or password' },
      401
    )
  }

  return c.json(
    {
      token: result.token,
      tenant_id: result.tenant_id,
      email: result.email
    },
    200
  )
})

export default auth
import { Hono } from 'hono';
import type { Bindings } from '../types';
import { authMiddleware, getTenantId } from '../lib/auth';
import { logAudit } from '../lib/audit';

const settings = new Hono<{ Bindings: Bindings }>();

// Apply auth middleware
settings.use('/*', authMiddleware);

// Get shop settings
settings.get('/', async (c) => {
  const tenantId = getTenantId(c);
  
  const result = await c.env.DB.prepare(
    'SELECT * FROM shop_settings WHERE tenant_id = ?'
  ).bind(tenantId).first();
  
  if (!result) {
    // Create default settings if not exists
    await c.env.DB.prepare(
      'INSERT INTO shop_settings (tenant_id) VALUES (?)'
    ).bind(tenantId).run();
    
    return c.json({
      tenant_id: tenantId,
      shop_logo_url: null,
      upi_id: null,
      bank_name: null,
      account_number: null,
      ifsc_code: null,
      branch: null,
      payment_qr_code_url: null
    });
  }
  
  return c.json(result);
});

// Update shop settings
settings.patch('/', async (c) => {
  const tenantId = getTenantId(c);
  
  try {
    const oldSettings = await c.env.DB.prepare(
      'SELECT * FROM shop_settings WHERE tenant_id = ?'
    ).bind(tenantId).first();
    
    const updates = await c.req.json();
    const allowedFields = [
      'shop_logo_url',
      'upi_id',
      'bank_name',
      'account_number',
      'ifsc_code',
      'branch',
      'payment_qr_code_url'
    ];
    
    const setClause = [];
    const params = [];
    
    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        setClause.push(`${field} = ?`);
        params.push(updates[field]);
      }
    }
    
    if (setClause.length === 0) {
      return c.json({ error: 'No fields to update' }, 400);
    }
    
    setClause.push('updated_at = CURRENT_TIMESTAMP');
    params.push(tenantId);
    
    if (oldSettings) {
      // Update existing
      await c.env.DB.prepare(`
        UPDATE shop_settings
        SET ${setClause.join(', ')}
        WHERE tenant_id = ?
      `).bind(...params).run();
    } else {
      // Insert new
      const fields = ['tenant_id', ...allowedFields.filter(f => updates[f] !== undefined)];
      const values = [tenantId, ...allowedFields.filter(f => updates[f] !== undefined).map(f => updates[f])];
      const placeholders = fields.map(() => '?').join(', ');
      
      await c.env.DB.prepare(`
        INSERT INTO shop_settings (${fields.join(', ')})
        VALUES (${placeholders})
      `).bind(...values).run();
    }
    
    await logAudit(c, 'UPDATE', 'shop_settings', tenantId, oldSettings, updates);
    
    return c.json({ success: true });
  } catch (error: any) {
    console.error('Settings update error:', error);
    return c.json({ error: 'Failed to update settings', details: error.message }, 500);
  }
});

// Upload file to R2
settings.post('/upload', async (c) => {
  const tenantId = getTenantId(c);
  
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const type = formData.get('type') as string; // 'logo', 'qr', 'customer', 'product'
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }
    
    // Generate unique filename
    const timestamp = Date.now();
    const extension = file.name.split('.').pop();
    const filename = `${tenantId}/${type}/${timestamp}.${extension}`;
    
    // Upload to R2
    const arrayBuffer = await file.arrayBuffer();
    await c.env.STORAGE.put(filename, arrayBuffer, {
      httpMetadata: {
        contentType: file.type
      }
    });
    
    // Generate public URL (will need to configure R2 bucket for public access or use signed URLs)
    const url = `/api/storage/${filename}`;
    
    await logAudit(c, 'UPLOAD', 'file', undefined, null, { filename, type });
    
    return c.json({
      success: true,
      url,
      filename
    });
  } catch (error: any) {
    console.error('Upload error:', error);
    return c.json({ error: 'Upload failed', details: error.message }, 500);
  }
});

// Get file from R2
settings.get('/storage/*', async (c) => {
  const path = c.req.param('*');
  
  try {
    const object = await c.env.STORAGE.get(path);
    
    if (!object) {
      return c.notFound();
    }
    
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('Cache-Control', 'public, max-age=31536000');
    
    return new Response(object.body, { headers });
  } catch (error: any) {
    console.error('Storage retrieval error:', error);
    return c.json({ error: 'File not found' }, 404);
  }
});

export default settings;

import { Hono } from 'hono';
import type { Bindings } from '../types';
import { authMiddleware, getTenantId } from '../lib/auth';

const audit = new Hono<{ Bindings: Bindings }>();

// Apply auth middleware
audit.use('/*', authMiddleware);

// Get audit logs
audit.get('/', async (c) => {
  const tenantId = getTenantId(c);
  const limit = parseInt(c.req.query('limit') || '100');
  const offset = parseInt(c.req.query('offset') || '0');
  const entityType = c.req.query('entity_type');
  const action = c.req.query('action');
  
  let query = 'SELECT * FROM audit_logs WHERE tenant_id = ?';
  const params: any[] = [tenantId];
  
  if (entityType) {
    query += ' AND entity_type = ?';
    params.push(entityType);
  }
  
  if (action) {
    query += ' AND action = ?';
    params.push(action);
  }
  
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);
  
  const result = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json({
    logs: result.results,
    limit,
    offset
  });
});

export default audit;

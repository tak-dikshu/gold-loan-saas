export type Bindings = {
  DB: D1Database;
  STORAGE: R2Bucket;
  JWT_SECRET?: string;
}

export interface Tenant {
  id: number;
  shop_name: string;
  email: string;
  password_hash: string;
  phone?: string;
  address?: string;
  created_at: string;
  updated_at: string;
}

export interface ShopSettings {
  id: number;
  tenant_id: number;
  shop_logo_url?: string;
  upi_id?: string;
  bank_name?: string;
  account_number?: string;
  ifsc_code?: string;
  branch?: string;
  payment_qr_code_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: number;
  tenant_id: number;
  name: string;
  phone: string;
  address?: string;
  id_proof_type?: string;
  id_proof_number?: string;
  customer_photo_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Loan {
  id: number;
  tenant_id: number;
  customer_id: number;
  loan_number: string;
  product_photo_url?: string;
  gross_weight: number;
  stone_weight: number;
  net_weight: number;
  purity: '18K' | '22K' | '24K';
  gold_rate_per_gram: number;
  ltv_percentage: number;
  loan_amount: number;
  principal_remaining: number;
  interest_rate_30: number;
  interest_rate_60: number;
  interest_rate_90: number;
  status: 'active' | 'closed' | 'overdue';
  loan_date: string;
  maturity_date?: string;
  last_payment_date?: string;
  closed_date?: string;
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: number;
  tenant_id: number;
  loan_id: number;
  transaction_type: 'interest' | 'principal' | 'partial' | 'full';
  amount: number;
  interest_paid: number;
  principal_paid: number;
  payment_method: string;
  payment_date: string;
  notes?: string;
  created_by?: number;
  created_at: string;
}

export interface AuditLog {
  id: number;
  tenant_id: number;
  user_id: number;
  action: string;
  entity_type: string;
  entity_id?: number;
  old_values?: string;
  new_values?: string;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

export interface LoanWithCustomer extends Loan {
  customer_name: string;
  customer_phone: string;
  days_elapsed: number;
  interest_due: number;
  total_amount_due: number;
}

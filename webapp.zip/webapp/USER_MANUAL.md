# User Manual - Gold Loan Management SaaS
## Complete Guide for Jewelry Shop Owners

---

## 📖 Table of Contents

1. [Getting Started](#getting-started)
2. [Dashboard Overview](#dashboard-overview)
3. [Creating a New Loan](#creating-a-new-loan)
4. [Managing Loans](#managing-loans)
5. [Processing Payments](#processing-payments)
6. [Customer Management](#customer-management)
7. [Shop Settings](#shop-settings)
8. [WhatsApp Reminders](#whatsapp-reminders)
9. [Reports and Audit Logs](#reports-and-audit-logs)
10. [Mobile App Usage](#mobile-app-usage)
11. [Troubleshooting](#troubleshooting)

---

## Getting Started

### Creating Your Account

1. **Open the Application**
   - Visit your shop's Gold Loan SaaS URL
   - You'll see the login screen

2. **Register Your Shop**
   - Click the "Register" tab
   - Fill in the form:
     - **Shop Name**: Your jewelry shop's name
     - **Email**: Your business email (this will be your username)
     - **Phone**: Your contact number
     - **Password**: Create a strong password (minimum 6 characters)
   - Click "Register Shop"
   - You'll be automatically logged in

3. **First Login**
   - After registration, you're taken to the dashboard
   - **Important**: First configure your shop settings before creating loans

---

## Dashboard Overview

### Main Dashboard Sections

#### 1. **Statistics Cards** (Top Section)
Four colorful cards showing:

- **💰 PRINCIPAL** (Blue)
  - Total outstanding principal amount
  - Number of active loans

- **📊 INTEREST** (Green)
  - Total interest amount due across all loans
  - Real-time calculation

- **📋 ACTIVE** (Amber)
  - Count of currently active loans

- **⚠️ OVERDUE** (Red)
  - Loans older than 90 days
  - Animated badge when overdue loans exist

#### 2. **Overdue Alerts Section**
- Shows when loans exceed 90 days
- Displays top 5 overdue loans
- Each alert shows:
  - Customer name
  - Loan number
  - Days elapsed
  - Total amount due
  - Quick "Send Reminder" button

#### 3. **Recent Loans Table**
- Shows latest 10 loans
- Columns:
  - Loan # (unique identifier)
  - Customer (name and phone)
  - Date (loan creation date)
  - Principal Remaining
  - Interest Due
  - Status (Active/Closed/Overdue)
  - Actions (View/PDF/WhatsApp)

### Navigation Menu

Located at the top of every page:

- **🏠 Dashboard**: Overview and statistics
- **💼 Loans**: Complete list of all loans
- **👥 Customers**: Customer database
- **⚙️ Settings**: Shop configuration
- **➕ New Loan**: Create new gold loan (prominent button)
- **🚪 Logout**: Sign out of the system

---

## Creating a New Loan

### Step-by-Step Process

#### Step 1: Click "New Loan"
- Large orange button in top-right corner of navigation bar

#### Step 2: Customer Information

**Required Fields:**
- **Customer Name**: Full name as per ID proof
- **Phone Number**: With country code (e.g., +91 98765 43210)

**Optional Fields:**
- **Address**: Residential address
- **ID Proof Type**: Select from dropdown
  - Aadhaar Card
  - PAN Card
  - Voter ID
  - Passport
  - Driving License
- **ID Proof Number**: Corresponding ID number
- **Customer Photo**: Click "Capture Photo" to take picture using device camera

#### Step 3: Gold Ornament Details

**Required Fields:**

1. **Gross Weight (grams)**
   - Total weight including stones
   - Enter precise weight from your weighing scale
   - Example: 50.5

2. **Stone Weight (grams)**
   - Weight of stones/gems if any
   - Leave as 0 if no stones
   - Example: 2.5

3. **Net Weight**
   - Automatically calculated: Gross - Stone
   - Shows in readonly field
   - Example: 48.0 (50.5 - 2.5)

4. **Purity**
   - Select from dropdown:
     - **18K** (75% pure gold)
     - **22K** (91.67% pure gold)
     - **24K** (100% pure gold)

5. **Gold Rate (₹/gram)**
   - Enter today's market rate per gram
   - Example: 6500
   - This rate is specific to this loan

6. **LTV % (Loan-to-Value)**
   - Default: 75%
   - Adjustable (typically 70-85%)
   - Lower percentage = safer lending

7. **Loan Amount**
   - Automatically calculated using formula:
   - **Formula**: Net Weight × Gold Rate × Purity Factor × LTV%
   - Displays in large amber box
   - Example: 48 × 6500 × 0.9167 × 0.75 = ₹214,353

8. **Product Photo**
   - **Required**: Must capture ornament photo
   - Click "Capture Photo"
   - Take clear picture of the gold item
   - Image automatically compressed to save space

#### Step 4: Interest Rate Configuration

Set interest rates for different time periods:

- **0-30 Days Rate**: Default 1.5% per month
- **31-60 Days Rate**: Default 2.0% per month
- **61+ Days Rate**: Default 2.5% per month

**How Interest Works:**
- Interest calculated daily based on days elapsed
- Rate automatically increases after 30 and 60 days
- Formula: (Principal × Rate × Days) / 100 / 30

**Example:**
- Loan: ₹2,00,000
- Days: 45 (falls in 31-60 day range)
- Rate: 2.0%
- Interest = (200000 × 2.0 × 45) / 100 / 30 = ₹6,000

#### Step 5: Loan Date
- Default: Today's date
- Can be changed if backdating required
- Format: YYYY-MM-DD

#### Step 6: Submit

1. Review all information carefully
2. Click "Create Loan & Generate PDF"
3. System will:
   - Upload customer and product photos
   - Create loan record
   - Generate PDF sanction letter
   - Download PDF automatically

---

## Managing Loans

### Viewing All Loans

1. Click "Loans" in navigation menu
2. You'll see a filterable table of all loans

### Search and Filters

**Search Box:**
- Type customer name, phone, or loan number
- Results update as you type
- Case-insensitive search

**Filter by Status:**
- All Status (default)
- Active only
- Closed only
- Overdue only

**Filter by Date:**
- Start Date: Beginning of date range
- End Date: End of date range
- Leave empty to see all dates

**Reset Filters:**
- Click "Reset Filters" button to clear all filters

### Loan Details Page

Click the eye icon (👁️) next to any loan to view full details.

**Page Sections:**

1. **Loan Header**
   - Loan number and creation date
   - Current status badge
   - Overdue warning if >90 days

2. **Financial Summary Cards**
   - Principal Remaining
   - Interest Due (real-time)
   - Days Elapsed
   - Total Amount Due

3. **Customer Details**
   - Photo (if available)
   - Name, phone, address
   - "Send Payment Reminder" button

4. **Gold Ornament Details**
   - Product photo
   - Weight details (gross, stone, net)
   - Purity and gold rate
   - LTV percentage

5. **Transaction History**
   - All payments made on this loan
   - Each transaction shows:
     - Payment type
     - Date and payment method
     - Total amount
     - Interest paid
     - Principal paid
     - Any notes

6. **Quick Actions Sidebar**
   - Download PDF
   - Print
   - Close Loan (if active)

---

## Processing Payments

### Making a Payment

1. Open the loan details page
2. Find "Make Payment" section on the right sidebar

### Payment Types

#### 1. Interest Only
- Pay only the accumulated interest
- Principal remains unchanged
- Amount pre-filled with current interest due

#### 2. Principal Only
- Pay towards principal amount
- No interest payment
- Reduces principal remaining

#### 3. Partial Payment
- Pay any amount
- System allocates:
  - First to interest (until interest is paid)
  - Remainder to principal
- Smart allocation ensures interest is cleared first

#### 4. Full Settlement
- Pay entire amount due (Principal + Interest)
- Automatically closes the loan
- Amount pre-filled with total due

### Payment Process

1. **Select Payment Type**
   - Choose from dropdown
   - Amount may auto-fill based on type

2. **Enter Amount** (if not auto-filled)
   - Enter payment amount in rupees
   - Can enter decimals (e.g., 5000.50)

3. **Select Payment Method**
   - Cash
   - UPI
   - Card
   - Bank Transfer

4. **Enter Payment Date**
   - Default: Today
   - Can backdate if needed

5. **Add Notes** (Optional)
   - Any remarks about the payment
   - Example: "Received via UPI - Ref# 123456"

6. **Click "Record Payment"**
   - Payment is immediately recorded
   - Principal updates instantly
   - Loan closes automatically if principal reaches zero
   - Page refreshes to show updated information

### Understanding Payment Effects

**Example 1: Interest-Only Payment**
- Before: Principal ₹2,00,000, Interest ₹6,000
- Payment: ₹6,000 (Interest Only)
- After: Principal ₹2,00,000, Interest ₹0 (resets)

**Example 2: Partial Payment**
- Before: Principal ₹2,00,000, Interest ₹6,000
- Payment: ₹10,000 (Partial)
- Allocation: ₹6,000 to interest, ₹4,000 to principal
- After: Principal ₹1,96,000, Interest ₹0

**Example 3: Full Settlement**
- Before: Principal ₹2,00,000, Interest ₹6,000
- Payment: ₹2,06,000 (Full)
- After: Loan CLOSED ✓

---

## Customer Management

### Viewing Customers

1. Click "Customers" in navigation
2. See all customers in card format
3. Each card shows:
   - Photo or initials
   - Name and phone
   - Address
   - "View Loans" button

### Customer Search

- Search box at top of customers page
- Type name or phone number
- Results update in real-time

### Viewing Customer Loan History

1. Click "View Loans" on customer card
2. System shows all loans for that customer
3. Helpful for:
   - Checking payment history
   - Verifying customer reliability
   - Making lending decisions

---

## Shop Settings

### Accessing Settings

1. Click "Settings" in navigation menu
2. Configure your shop information

### Shop Logo

**Purpose**: Appears on PDF invoices and print documents

**How to Upload**:
1. Click "Upload Logo" button
2. Select image file (PNG recommended)
3. Image automatically compresses
4. Preview shows immediately

**Recommendations**:
- Size: 500×500 pixels
- Format: PNG with transparent background
- File size: Under 1MB (system compresses to ~300KB)

### UPI Payment Details

**UPI ID**:
- Enter your shop's UPI ID
- Example: yourshop@paytm
- Appears on PDF invoices

### Bank Account Details

**Fields:**
- **Bank Name**: Full name of your bank
- **Account Number**: Your account number
- **IFSC Code**: Bank IFSC code
- **Branch**: Branch name or location

**Purpose**:
- All details appear on PDF sanction letters
- Customers can make direct bank transfers

### Payment QR Code

**Purpose**: Enables customers to scan and pay instantly

**How to Upload**:
1. Generate QR code from your payment app (Google Pay, PhonePe, Paytm, etc.)
2. Save QR code as image
3. Click "Upload QR Code" in settings
4. Select QR code image
5. QR code now appears on all PDF invoices

**Tip**: Use high-contrast QR code for better scanning

### Saving Settings

1. Fill in all desired fields
2. Click "Save Settings" button
3. Success message confirms save
4. Settings apply immediately to new PDFs

---

## WhatsApp Reminders

### Sending Payment Reminders

**From Dashboard**:
1. Find loan in "Recent Loans" or "Overdue Alerts"
2. Click WhatsApp icon (green)

**From Loans List**:
1. Find loan in table
2. Click WhatsApp icon in Actions column

**From Loan Details**:
1. Open any loan
2. Click "Send Payment Reminder" button

### What Happens

1. WhatsApp opens automatically
2. Message is pre-filled with:
   ```
   Dear [Customer Name],
   
   Your interest payment of ₹[Amount] is due for Loan ID: [Loan Number].
   
   Please make the payment at your earliest convenience.
   
   Thank you,
   [Your Shop Name]
   ```
3. Customer contact is automatically filled
4. You can edit message before sending
5. Click send to deliver via WhatsApp

### Tips for Effective Reminders

- Send reminders before 30-day mark to avoid rate increase
- Send polite follow-ups for overdue loans
- Maintain professional tone
- Include payment options (UPI ID, account details)

---

## Reports and Audit Logs

### Viewing Audit Logs

1. Go to Settings page
2. Click "View Audit Logs" button
3. See complete history of all actions

### What's Logged

- User login/logout
- Loan creation
- Loan updates
- Payment processing
- Settings changes
- File uploads

### Audit Log Details

Each entry shows:
- **Time**: When action occurred
- **Action**: Type of operation (CREATE, UPDATE, PAYMENT, etc.)
- **Entity**: What was affected (loan, customer, settings)
- **Details**: Specific changes made
- **IP Address**: Where action came from

### Why Audit Logs Matter

- **Accountability**: Track who did what and when
- **Transparency**: Complete business record
- **Dispute Resolution**: Evidence for any disagreements
- **Compliance**: Meet regulatory requirements
- **Security**: Detect unauthorized access

---

## Mobile App Usage

### Installing as Mobile App (PWA)

**On Android (Chrome)**:
1. Open app in Chrome browser
2. Tap menu (⋮) → "Install app" or "Add to Home screen"
3. App icon appears on home screen
4. Opens like native app (no browser UI)

**On iPhone (Safari)**:
1. Open app in Safari
2. Tap Share button (⬆️)
3. Scroll and tap "Add to Home Screen"
4. Tap "Add"
5. App appears on home screen

### Mobile Features

#### Camera Capture
- Both customer and product photos use device camera
- Front camera for customer photo
- Rear camera for product photo
- Images automatically compressed before upload

#### Touch-Friendly Design
- Large buttons and touch targets
- Swipe-friendly tables
- Responsive layout adjusts to screen size
- No accidental taps

#### Offline Capability
- Core app files cached for offline access
- View previously loaded data
- Seamless experience even with poor connectivity

### Mobile Best Practices

1. **Good Lighting**: Take photos in well-lit areas
2. **Steady Hand**: Hold device steady for clear photos
3. **Portrait Mode**: Use phone in portrait orientation
4. **WiFi for Uploads**: Use WiFi for faster image uploads
5. **Regular Sync**: Open app daily to sync latest data

---

## Troubleshooting

### Common Issues and Solutions

#### Issue: "Failed to login"
**Solutions**:
- Check email and password are correct
- Ensure email is lowercase
- Reset password if forgotten (contact admin)
- Clear browser cache and try again

#### Issue: "Images not uploading"
**Solutions**:
- Check internet connection
- Ensure camera permissions are granted
- Try smaller image file
- Use different browser
- Check storage space on device

#### Issue: "PDF not downloading"
**Solutions**:
- Allow pop-ups in browser settings
- Check download folder permissions
- Try different browser
- Ensure PDF viewer app is installed

#### Issue: "Can't see some loans"
**Solutions**:
- Check filter settings
- Click "Reset Filters"
- Verify date range is correct
- Ensure status filter is set to "All"

#### Issue: "Interest calculation seems wrong"
**Check**:
- Loan date is correct
- Today's date is accurate
- Interest rates are properly configured
- Number of days elapsed matches expectations

**Formula**:
Interest = (Principal × Rate × Days) / 100 / 30

#### Issue: "WhatsApp not opening"
**Solutions**:
- Ensure WhatsApp is installed
- Update WhatsApp to latest version
- Check phone number format (+91...)
- Try copying message manually

#### Issue: "App is slow"
**Solutions**:
- Clear browser cache
- Close other browser tabs
- Check internet speed
- Restart device
- Try incognito/private mode

---

## Best Practices for Daily Use

### Morning Routine
1. Login to dashboard
2. Check overdue alerts
3. Send WhatsApp reminders for due payments
4. Review yesterday's transactions

### When Customer Visits
1. Search for customer by phone/name
2. Open active loan details
3. Show current interest due
4. Process payment immediately
5. Generate and print receipt

### End of Day
1. Review all payments received today
2. Verify all PDFs are generated
3. Check audit logs for day's activity
4. Note any follow-ups needed

### Weekly Tasks
1. Review all overdue loans
2. Send reminder messages
3. Back up important PDFs
4. Review dashboard statistics

### Monthly Tasks
1. Review audit logs for the month
2. Verify all loans are properly documented
3. Update shop settings if needed
4. Generate monthly reports

---

## Tips for Success

### Security
- Use strong password (mix of letters, numbers, symbols)
- Never share your login credentials
- Log out when leaving computer
- Use secure internet connection

### Organization
- Take clear photos of all items
- Use consistent naming for customers
- Add notes to payments for reference
- Keep loan dates accurate

### Customer Service
- Respond quickly to payment reminders
- Be professional in communications
- Maintain accurate records
- Process payments promptly

### Financial Management
- Set competitive interest rates
- Monitor overdue loans closely
- Keep LTV percentage reasonable
- Verify gold rates daily

---

## Getting Help

### Need Assistance?

1. **Check this manual** for detailed instructions
2. **Review README.md** for technical details
3. **Contact support** (details in main README)
4. **Check audit logs** for activity history

---

## Glossary

**Terms Explained:**

- **LTV (Loan-to-Value)**: Percentage of gold value given as loan
- **Gross Weight**: Total weight including stones
- **Net Weight**: Pure gold weight (gross minus stone)
- **Purity**: Gold content (18K=75%, 22K=91.67%, 24K=100%)
- **Principal**: Original loan amount (excluding interest)
- **Interest**: Amount charged for borrowing
- **Overdue**: Loan exceeding 90 days
- **Sanction Letter**: PDF document with loan details
- **JWT**: Secure login token (automatic, no action needed)
- **PWA**: Progressive Web App (installable like mobile app)
- **Audit Log**: Complete history of all system actions

---

## Quick Reference Card

### Most Common Actions

| Action | Steps |
|--------|-------|
| Create Loan | New Loan → Fill form → Capture photos → Submit |
| Record Payment | Open loan → Make Payment → Select type → Enter amount → Submit |
| Send Reminder | Find loan → Click WhatsApp icon → Send |
| View Reports | Dashboard → Check statistics cards |
| Download PDF | Open loan → Download PDF button |
| Update Settings | Settings → Upload logo/QR → Save |

---

**📞 Support Available**  
If you encounter any issues not covered in this manual, please refer to the main README.md or contact technical support.

**Happy Gold Lending! 💛**

# Deployment Guide - Gold Loan Management SaaS

## 🚀 Complete Deployment Instructions

This guide will walk you through deploying the Gold Loan Management SaaS to Cloudflare Pages for production use.

---

## Prerequisites

Before you begin, ensure you have:

1. **Cloudflare Account** (Free tier is sufficient)
   - Sign up at https://dash.cloudflare.com/sign-up

2. **Cloudflare API Token** with the following permissions:
   - Account: Cloudflare Pages: Edit
   - Account: D1: Edit
   - Account: R2: Edit
   
   Create at: https://dash.cloudflare.com/profile/api-tokens

3. **Node.js and npm** installed locally
   - Version 18.0.0 or higher

4. **Git** installed and configured

---

## Step 1: Setup Cloudflare Authentication

### Option A: Using Environment Variable (Recommended for CI/CD)

```bash
export CLOUDFLARE_API_TOKEN="your-api-token-here"
```

### Option B: Using wrangler login (Interactive)

```bash
npx wrangler login
```

### Verify Authentication

```bash
npx wrangler whoami
```

Expected output:
```
You are logged in with an API Token, associated with the email '...@example.com'.
```

---

## Step 2: Create Cloudflare D1 Database

### Create Production Database

```bash
cd /home/user/webapp
npx wrangler d1 create gold-loan-production
```

### Copy Database ID

You'll see output like:
```
Created database gold-loan-production!
Database ID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

### Update wrangler.jsonc

Edit `wrangler.jsonc` and update the `database_id`:

```json
{
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "gold-loan-production",
      "database_id": "paste-your-database-id-here"
    }
  ]
}
```

---

## Step 3: Create Cloudflare R2 Bucket

```bash
npx wrangler r2 bucket create gold-loan-storage
```

Expected output:
```
Created bucket 'gold-loan-storage'
```

---

## Step 4: Apply Database Migrations

### Apply to Production Database

```bash
npm run db:migrate:prod
```

This will create all necessary tables and indexes in your production D1 database.

---

## Step 5: Create Cloudflare Pages Project

### Create Project

```bash
npx wrangler pages project create gold-loan-saas --production-branch main
```

### Configure Bindings

The project automatically uses bindings from `wrangler.jsonc`:
- D1 Database: `DB`
- R2 Bucket: `STORAGE`

---

## Step 6: Build and Deploy

### Build the Application

```bash
npm run build
```

This creates the `dist/` directory with:
- `_worker.js` - Compiled Hono backend
- `_routes.json` - Routing configuration
- Static assets from `public/`

### Deploy to Cloudflare Pages

```bash
npm run deploy
```

Or manually:

```bash
npx wrangler pages deploy dist --project-name gold-loan-saas
```

---

## Step 7: Access Your Deployment

After successful deployment, you'll see URLs like:

- **Production URL**: `https://gold-loan-saas.pages.dev`
- **Branch URL**: `https://main.gold-loan-saas.pages.dev`

---

## Step 8: Optional Configuration

### Set Environment Variables/Secrets

If you need to add environment variables:

```bash
# Add JWT secret (optional, uses default if not set)
echo "your-secret-key" | npx wrangler pages secret put JWT_SECRET --project-name gold-loan-saas
```

### Configure Custom Domain

1. Go to Cloudflare Pages dashboard
2. Select your project (`gold-loan-saas`)
3. Go to "Custom domains" tab
4. Click "Set up a custom domain"
5. Follow the instructions to add your domain

---

## Step 9: Seed Demo Data (Optional)

If you want to create a demo account in production:

```bash
# Create SQL file with hashed password
# Note: Generate actual bcrypt hash for production
npx wrangler d1 execute gold-loan-production --file=./seed.sql
```

---

## Troubleshooting

### Issue: "Database not found"

**Solution**: Ensure you've created the D1 database and updated `wrangler.jsonc` with the correct `database_id`.

### Issue: "R2 bucket not found"

**Solution**: Create the R2 bucket with:
```bash
npx wrangler r2 bucket create gold-loan-storage
```

### Issue: "Authentication failed"

**Solution**: 
1. Verify API token has correct permissions
2. Try `npx wrangler logout` then `npx wrangler login` again
3. Check token hasn't expired

### Issue: "Build fails"

**Solution**:
1. Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`
2. Clear build cache: `rm -rf dist .wrangler`
3. Try building again: `npm run build`

### Issue: "Images not uploading"

**Solution**:
1. Verify R2 bucket exists: `npx wrangler r2 bucket list`
2. Check R2 binding in `wrangler.jsonc` matches bucket name
3. Ensure `STORAGE` binding is correctly configured

---

## Continuous Deployment with GitHub Actions

### Create `.github/workflows/deploy.yml`

```yaml
name: Deploy to Cloudflare Pages

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm install
      
      - name: Build
        run: npm run build
      
      - name: Deploy to Cloudflare Pages
        uses: cloudflare/pages-action@v1
        with:
          apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
          accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
          projectName: gold-loan-saas
          directory: dist
          gitHubToken: ${{ secrets.GITHUB_TOKEN }}
```

### Add GitHub Secrets

1. Go to your GitHub repository
2. Settings → Secrets and variables → Actions
3. Add:
   - `CLOUDFLARE_API_TOKEN`: Your Cloudflare API token
   - `CLOUDFLARE_ACCOUNT_ID`: Your Cloudflare Account ID

---

## Production Checklist

Before going live, verify:

- [ ] Database migrations applied successfully
- [ ] R2 bucket created and accessible
- [ ] Environment variables/secrets configured
- [ ] Custom domain configured (optional)
- [ ] SSL certificate active (automatic with Cloudflare)
- [ ] Test user registration
- [ ] Test loan creation with images
- [ ] Test PDF generation with shop logo
- [ ] Test payment processing
- [ ] Test on mobile devices
- [ ] Verify PWA installation works
- [ ] Check all navigation and back buttons work
- [ ] Test WhatsApp integration
- [ ] Verify audit logs are recording
- [ ] Test camera capture on real mobile device

---

## Monitoring and Logs

### View Application Logs

```bash
# Tail logs in real-time
npx wrangler pages deployment tail --project-name gold-loan-saas
```

### View D1 Database Stats

```bash
# List all databases
npx wrangler d1 list

# Get database info
npx wrangler d1 info gold-loan-production
```

### View R2 Bucket Usage

```bash
# List buckets
npx wrangler r2 bucket list

# List objects in bucket
npx wrangler r2 object list --bucket gold-loan-storage
```

---

## Backup and Recovery

### Backup D1 Database

```bash
# Export database to SQL
npx wrangler d1 export gold-loan-production --output=backup-$(date +%Y%m%d).sql
```

### Restore from Backup

```bash
# Import SQL backup
npx wrangler d1 execute gold-loan-production --file=backup-20240101.sql
```

### Backup R2 Files

```bash
# Download all files from R2
npx wrangler r2 object download --bucket gold-loan-storage --remote=* --local=./r2-backup/
```

---

## Scaling Considerations

### Database
- Cloudflare D1 automatically scales
- Free tier: 5GB storage, 5 million reads/day
- Paid tier: 50GB storage, 50 million reads/day

### File Storage (R2)
- No egress fees
- Free tier: 10GB storage, 1 million Class A operations
- Scales infinitely

### Workers/Pages
- Free tier: 100,000 requests/day
- Paid tier: Unlimited requests
- Global CDN distribution included

---

## Security Best Practices

1. **Use Strong JWT Secret**
   - Generate with: `openssl rand -base64 32`
   - Set as environment variable

2. **Enable Cloudflare Security Features**
   - WAF (Web Application Firewall)
   - DDoS protection
   - Rate limiting

3. **Regular Backups**
   - Automate daily database backups
   - Store backups securely off-platform

4. **Monitor Audit Logs**
   - Review regularly for suspicious activity
   - Set up alerts for unusual patterns

5. **Update Dependencies**
   - Run `npm audit` regularly
   - Keep dependencies up to date

---

## Support

For deployment issues:
1. Check Cloudflare Status: https://www.cloudflarestatus.com/
2. Cloudflare Docs: https://developers.cloudflare.com/pages/
3. Wrangler Docs: https://developers.cloudflare.com/workers/wrangler/

---

## Cost Estimation

### Free Tier (Perfect for Starting)
- Cloudflare Pages: Free
- D1 Database: Free (up to 5GB)
- R2 Storage: Free (up to 10GB)
- Workers: Free (up to 100k requests/day)

**Total: $0/month** for small to medium jewelry shops

### Paid Tier (High Volume)
- Workers Paid Plan: $5/month (unlimited requests)
- D1 Storage: ~$1/GB/month beyond 5GB
- R2 Storage: $0.015/GB/month beyond 10GB

**Total: ~$10-20/month** for large operations

---

## Deployment Complete! 🎉

Your Gold Loan Management SaaS is now live and accessible globally via Cloudflare's edge network.

**Next Steps**:
1. Register your first shop account
2. Configure shop settings (logo, bank details, QR code)
3. Create your first loan
4. Test all features thoroughly
5. Train staff on using the system

---

**Questions?** Refer to the main README.md for feature documentation and user manual.

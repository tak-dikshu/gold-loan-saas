-- Demo tenant for testing
-- Password: demo123
INSERT OR IGNORE INTO tenants (id, shop_name, email, password_hash, phone, address) 
VALUES (1, 'Golden Jewelers', 'demo@goldloan.com', '$2a$10$YourHashedPasswordHere', '+91 98765 43210', '123 Main Street, Mumbai, Maharashtra');

-- Demo shop settings
INSERT OR IGNORE INTO shop_settings (tenant_id, upi_id, bank_name, account_number, ifsc_code, branch)
VALUES (1, 'goldenjewelers@upi', 'State Bank of India', '1234567890', 'SBIN0001234', 'Main Branch');

-- Demo customer
INSERT OR IGNORE INTO customers (id, tenant_id, name, phone, address, id_proof_type, id_proof_number)
VALUES (1, 1, 'Rajesh Kumar', '+91 98765 00001', '456 Park Avenue, Mumbai', 'Aadhaar', '1234 5678 9012');

-- Demo loan
INSERT OR IGNORE INTO loans (
  id, tenant_id, customer_id, loan_number,
  gross_weight, stone_weight, net_weight, purity,
  gold_rate_per_gram, ltv_percentage, loan_amount, principal_remaining,
  interest_rate_30, interest_rate_60, interest_rate_90,
  status, loan_date
) VALUES (
  1, 1, 1, 'GL1-DEMO001',
  50.5, 2.5, 48.0, '22K',
  6500, 75, 219375, 219375,
  1.5, 2.0, 2.5,
  'active', date('now', '-45 days')
);

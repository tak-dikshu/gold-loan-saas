-- ===============================
-- Gold Loan Management SaaS
-- Initial Database Schema (FINAL)
-- ===============================

-- ===============================
-- Tenants (Jewelry Shops)
-- ===============================
CREATE TABLE IF NOT EXISTS tenants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shop_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ===============================
-- Shop Settings
-- ===============================
CREATE TABLE IF NOT EXISTS shop_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  shop_logo_url TEXT,
  upi_id TEXT,
  bank_name TEXT,
  account_number TEXT,
  ifsc_code TEXT,
  branch TEXT,
  payment_qr_code_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- ===============================
-- Customers
-- ===============================
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT,
  id_proof_type TEXT,
  id_proof_number TEXT,
  customer_photo_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- ===============================
-- Loans (Correct Financial Model)
-- ===============================
CREATE TABLE IF NOT EXISTS loans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  customer_id INTEGER NOT NULL,
  loan_number TEXT NOT NULL UNIQUE,

  -- Product
  product_photo_url TEXT,
  gross_weight REAL NOT NULL,
  stone_weight REAL DEFAULT 0,
  net_weight REAL NOT NULL,
  purity TEXT NOT NULL CHECK (purity IN ('18K', '22K', '24K')),

  -- Valuation
  gold_rate_per_gram REAL NOT NULL,
  ltv_percentage REAL NOT NULL DEFAULT 75,
  loan_amount REAL NOT NULL,

  -- Financial State (CRITICAL)
  outstanding_principal REAL NOT NULL,
  accrued_interest REAL NOT NULL DEFAULT 0,
  last_interest_calculated_at DATE NOT NULL,

  -- Interest Slabs (Monthly %)
  interest_rate_30 REAL NOT NULL DEFAULT 1.5,
  interest_rate_60 REAL NOT NULL DEFAULT 2.0,
  interest_rate_90 REAL NOT NULL DEFAULT 2.5,

  -- Status
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'closed', 'overdue')),

  loan_date DATE NOT NULL,
  last_payment_date DATE,
  closed_date DATE,

  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- ===============================
-- Transactions (Payments)
-- ===============================
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  loan_id INTEGER NOT NULL,

  transaction_type TEXT NOT NULL
    CHECK (transaction_type IN ('interest', 'principal', 'partial', 'full')),

  amount REAL NOT NULL,
  interest_paid REAL NOT NULL DEFAULT 0,
  principal_paid REAL NOT NULL DEFAULT 0,

  payment_method TEXT DEFAULT 'cash',
  payment_date DATE NOT NULL,
  notes TEXT,

  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
);

-- ===============================
-- Audit Logs
-- ===============================
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id INTEGER,
  old_values TEXT,
  new_values TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- ===============================
-- Indexes
-- ===============================
CREATE INDEX IF NOT EXISTS idx_customers_tenant_phone
  ON customers(tenant_id, phone);

CREATE INDEX IF NOT EXISTS idx_loans_tenant_status
  ON loans(tenant_id, status);

CREATE INDEX IF NOT EXISTS idx_transactions_loan
  ON transactions(loan_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant
  ON audit_logs(tenant_id);